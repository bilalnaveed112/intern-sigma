
<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://requestplugin
 * @since      1.0.0
 *
 * @package    Requestplugin
 * @subpackage Requestplugin/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Requestplugin
 * @subpackage Requestplugin/admin
 * @author     Sigma Square <info@sigmasquare.com>
 */
class Requestplugin_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;


	/**
	 * The activation key of registered users
	 */
	public $activation_key_value;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;
		if ( isset($_POST['activation_key']) && isset($_POST['activation_key']) ) {
			$activation_key = sanitize_text_field($_POST['activation_key']);
			$this->activation_key_value = $activation_key;
		}

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Requestplugin_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Requestplugin_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/requestplugin-admin.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Requestplugin_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Requestplugin_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/requestplugin-admin.js', array( 'jquery' ), $this->version, false );

	}

	public function admin_content_creator_page()
    {
        add_menu_page(
			'Content Geerator', 				 // Page Title
			'Content Request' , 				 // Page Menu Title
			'manage_options',   				 // Capability
			'content_creator_request',  		 // Page Slug
        	[$this, 'auto_content_creation'],    // Page Function
			'dashicons-welcome-write-blog', 3);  // Icon


		add_submenu_page(
			'content_creator_request', 						// Parent menu slug
			'Settings', 									// Subpage title
			'Settings', 									// Subpage menu title
			'manage_options', 								// Capability required to access the subpage
			'content_creator_request_settings', 			// Subpage slug
			[$this, 'content_creator_key_validation'] 		// Function to display the subpage content
		);
    }

	public function auto_content_creation()
    {
        /*
         * This shortcode function will provide two inputs. One for subject and
         * the other one is for keywords.
         *
         * You can enter subject and keywords here and get auto generated
         * content.
		 * Try and Enjoy!
		 */
		?>
		<div id="content_body">
			<h3><?php esc_html_e('Welcome to Auto Content Generator'); ?></h3>

			<form id="content_generation_form" action="" method="post">

				<div class="subject_input">
					<label for="">Enter Your Subject Here	</label>
					<input name="subject" type="text">
				</div>

				<div class="keyword_input">
					<label for="">Enter Your Keywords Here</label>
				<input name="keyword" type="text">
				</div>
			
				<input name="submit" type="submit" value="Generate Content">
				
			</form>

			<?php


			if (isset($_POST['subject']) && isset($_POST['keyword'])) {

				$current_user_id 		   = get_current_user_id();
				$registered_activation_key = get_user_meta($current_user_id, 'activation_key', TRUE);
				
				if(!empty($registered_activation_key)){

					// Make the API request
					$subject = sanitize_text_field($_POST['subject']);
					$keyword = sanitize_text_field($_POST['keyword']);

					$response = wp_remote_post('https://lookwearfeel.com/LWF/wp-json/auto-content-generator/v1/send-inputs', [
						'timeout'     => 100,
						'body' => [
							'subject' 		 => $subject,
							'keyword' 		 => $keyword,
							'key' 			 => $registered_activation_key,
						],
					]);

					if (is_wp_error($response)) {
						// Handle the error
						return false;
					} else {
						// Handle the success
						$responsed_data = json_decode(wp_remote_retrieve_body($response));
					}

					// Display Response?>
					<textarea id="responsed_data" rows="5">
					<?php echo trim($responsed_data); ?>			
					</textarea>
					<?php
				} else {
					echo 'Please Go to Setting Page and register your Activation Key';
				}
			}?>
		</div>
		<?php
    }

	public function content_creator_key_validation() {

		?>
		<br>
		<h3>General Settings</h3>
		<br>
		<div>
			<form method="post">
				<input type="text" name="activation_key">
				<input name="submit_key" type="submit" value="Register Your Key">
			</form>
		</div>
		<?php
		
		$current_user_id = get_current_user_id();
		$user_meta 		 = get_user_meta($current_user_id, 'activation_key', TRUE);
		
		if ( isset($_POST['activation_key']) ) {
			
			$activation_key  = sanitize_text_field($_POST['activation_key']);

			$response = wp_remote_post('https://lookwearfeel.com/LWF/wp-json/auto-content-generator/v1/key_validation', [
				'timeout'     => 100,
				'body' => [
					'key' => $activation_key,
				],
			]);

			if (is_wp_error($response)) {
				return false;
			} else {
				$responsed_data = json_decode(wp_remote_retrieve_body($response));
			}

			if($responsed_data == 1){
				if ($user_meta == ''){
					add_user_meta($current_user_id, 'activation_key', $activation_key);
					echo "Your Key is registered.";
				}
			} elseif($responsed_data == 0){
				echo "Your Key in Invalid";
			}
		}
		if(isset($user_meta)){
			echo 'Registeration Key: <strong>'.$user_meta.'</strong>';
		}
	}

}