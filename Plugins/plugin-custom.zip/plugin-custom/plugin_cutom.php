<?php
/*
Plugin Name: Custom Admin Pages
Plugin URI: https://example.com/plugins/the-basics/
Description: Custom Admin PAges
Version: 1.0
Author: Bilal
Author URI: https://author.example.com/
*/

add_action('wp_enqueue_scripts', 'custom_enqueue_scripts' );
function custom_enqueue_scripts(){
    wp_enqueue_style('style_css', plugin_dir_url(__FILE__)."assets/css/style.css");
    wp_enqueue_script('custom_script', plugin_dir_url(__FILE__)."assets/js/custom.js", array(), '1.0.0', true);
}

register_activation_hook(__FILE__, function(){});
register_deactivation_hook(__FILE__, function(){});


?>