<?php
/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @author Sohaib Muzammal <sohaib.muzammal@gmail.com>
 *
 * @since 1.0.0
 */
class Adreno 
{

    /**
     * The loader that's responsible for maintaining and registering all hooks that power
     * the plugin.
     *
     * @since 1.0.0
     *
     * @var Adreno_Loader maintains and registers all hooks for the plugin
     */
    protected $loader;

    /**
     * The unique identifier of this plugin.
     *
     * @since 1.0.0
     *
     * @var string the string used to uniquely identify this plugin
     */
    protected $plugin_name;

    /**
     * The current version of the plugin.
     *
     * @since 1.0.0
     *
     * @var string the current version of the plugin
     */
    protected $version;

    /**
     * Define the core functionality of the plugin.
     *
     * Set the plugin name and the plugin version that can be used throughout the plugin.
     * Load the dependencies, define the locale, and set the hooks for the admin area and
     * the public-facing side of the site.
     *
     * @since 1.0.0
     */
    public function __construct()
    {
        if (defined('ADRENO_VERSION')) {
            $this->version = ADRENO_VERSION;
        } else {
            $this->version = '1.0.0';
        }
        $this->plugin_name = 'adreno';

        $this->load_dependencies();
        $this->set_locale();
        $this->define_admin_hooks();
        $this->define_admin_ajax_calls();
        $this->define_public_hooks();
    }

    /**
     * Load the required dependencies for this plugin.
     *
     * Include the following files that make up the plugin:
     *
     * - Adreno_Loader. Orchestrates the hooks of the plugin.
     * - Adreno_i18n. Defines internationalization functionality.
     * - Adreno_Admin. Defines all hooks for the admin area.
     * - Adreno_Public. Defines all hooks for the public side of the site.
     *
     * Create an instance of the loader which will be used to register the hooks
     * with WordPress.
     *
     * @since 1.0.0
     */
    private function load_dependencies() 
    {
        /**
         * The class responsible for orchestrating the actions and filters of the
         * core plugin.
         */
        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-adreno-loader.php';

        /**
         * The class responsible for orchestrating the ajax actions and filters of the
         * core plugin.
         */
        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-adreno-ajax.php';


        /**
         * The class responsible for path of Adreno platform of the
         * core plugin.
         */
        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-adreno-paths.php';

        /**
         * The class responsible for defining internationalization functionality
         * of the plugin.
         */
        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-adreno-i18n.php';

        /**
         * The class responsible for defining all actions that occur in the admin area.
         */
        require_once plugin_dir_path(dirname(__FILE__)) . 'admin/class-adreno-admin.php';

        /**
         * The class responsible for defining all actions that occur in the public-facing
         * side of the site.
         */
        require_once plugin_dir_path(dirname(__FILE__)) . 'public/class-adreno-public.php';

        $this->loader = new Adreno_Loader();
    }

    /**
     * Define the locale for this plugin for internationalization.
     *
     * Uses the Adreno_i18n class in order to set the domain and to register the hook
     * with WordPress.
     *
     * @since 1.0.0
     */
    private function set_locale() {
        $plugin_i18n = new Adreno_i18n();

        $this->loader->add_action('plugins_loaded', $plugin_i18n, 'load_plugin_textdomain');
    }

    /**
     * Register all of the hooks related to the admin area functionality
     * of the plugin.
     *
     * @since 1.0.0
     */
    private function define_admin_hooks()
    {
        $plugin_admin = new Adreno_Admin($this->get_plugin_name(), $this->get_version());

        $this->loader->add_action('admin_enqueue_scripts', $plugin_admin, 'enqueue_styles');
        $this->loader->add_action('admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts');
        $this->loader->add_action('admin_menu', $plugin_admin, 'adrenoai_setting_page');
        $this->loader->add_action('admin_enqueue_scripts', $plugin_admin, 'adrenoai_enque_content_generator');

    }
    /**
     * Register all of the hooks related to the admin area functionality
     * of the plugin.
     *
     * @since 1.0.0
     */
    private function define_admin_ajax_calls() 
    {
        $plugin_ajax = new Adreno_Ajax($this->get_plugin_name(), $this->get_version());
        
        $this->loader->add_action('wp_ajax_adrenoai_user_validation', $plugin_ajax, 'adrenoai_user_validation');
        $this->loader->add_action('wp_ajax_nopriv_adrenoai_user_validation', $plugin_ajax, 'adrenoai_user_validation');
        $this->loader->add_action('wp_ajax_adrenoai_auto_generate_content', $plugin_ajax, 'adrenoai_auto_generate_content');
        $this->loader->add_action('wp_ajax_nopriv_adrenoai_auto_generate_content', $plugin_ajax, 'adrenoai_auto_generate_content');
        $this->loader->add_action('wp_ajax_adrenoai_key_validation', $plugin_ajax, 'adrenoai_key_validation');
        $this->loader->add_action('wp_ajax_nopriv_adrenoai_key_validation', $plugin_ajax, 'adrenoai_key_validation');
        $this->loader->add_action('wp_ajax_adrenoai_delete_registered_key', $plugin_ajax, 'adrenoai_delete_registered_key');
        $this->loader->add_action('wp_ajax_nopriv_adrenoai_delete_registered_key', $plugin_ajax, 'adrenoai_delete_registered_key');
        $this->loader->add_action('wp_ajax_adrenoai_update_text_credits', $plugin_ajax, 'adrenoai_update_text_credits');
        $this->loader->add_action('wp_ajax_nopriv_adrenoai_update_text_credits', $plugin_ajax, 'adrenoai_update_text_credits');
        $this->loader->add_action('wp_ajax_adrenoai_update_about_info', $plugin_ajax, 'adrenoai_update_about_info');
        $this->loader->add_action('wp_ajax_nopriv_adrenoai_update_about_info', $plugin_ajax, 'adrenoai_update_about_info');
        $this->loader->add_action('wp_ajax_adrenoai_suggest_keywords', $plugin_ajax, 'adrenoai_suggest_keywords');
        $this->loader->add_action('wp_ajax_nopriv_adrenoai_suggest_keywords', $plugin_ajax, 'adrenoai_suggest_keywords');
        $this->loader->add_action('wp_ajax_adrenoai_image_generation', $plugin_ajax, 'adrenoai_image_generation');
        $this->loader->add_action('wp_ajax_nopriv_adrenoai_image_generation', $plugin_ajax, 'adrenoai_image_generation');
        $this->loader->add_action('wp_ajax_adrenoai_add_featured_image', $plugin_ajax, 'adrenoai_add_featured_image');
        $this->loader->add_action('wp_ajax_nopriv_adrenoai_add_featured_image', $plugin_ajax, 'adrenoai_add_featured_image');
        $this->loader->add_action('wp_ajax_adrenoai_create_auto_title', $plugin_ajax, 'adrenoai_create_auto_title');
        $this->loader->add_action('wp_ajax_nopriv_adrenoai_create_auto_title', $plugin_ajax, 'adrenoai_create_auto_title');
        $this->loader->add_action('wp_ajax_adrenoai_create_auto_alt', $plugin_ajax, 'adrenoai_create_auto_alt');
        $this->loader->add_action('wp_ajax_nopriv_adrenoai_create_auto_alt', $plugin_ajax, 'adrenoai_create_auto_alt');
        $this->loader->add_action('wp_ajax_adrenoai_add_image_to_media_library', $plugin_ajax, 'adrenoai_add_image_to_media_library');
        $this->loader->add_action('wp_ajax_nopriv_adrenoai_add_image_to_media_library', $plugin_ajax, 'adrenoai_add_image_to_media_library');

    }

    /**
     * Register all of the hooks related to the public-facing functionality
     * of the plugin.
     *
     * @since 1.0.0
     */
    private function define_public_hooks() 
    {
        $plugin_public = new Adreno_Public($this->get_plugin_name(), $this->get_version());

        $this->loader->add_action('wp_enqueue_scripts', $plugin_public, 'enqueue_styles');
        $this->loader->add_action('wp_enqueue_scripts', $plugin_public, 'enqueue_scripts');
    }

    /**
     * Run the loader to execute all of the hooks with WordPress.
     *
     * @since 1.0.0
     */
    public function run() 
    {
        $this->loader->run();
    }

    /**
     * The name of the plugin used to uniquely identify it within the context of
     * WordPress and to define internationalization functionality.
     *
     * @since 1.0.0
     *
     * @return string the name of the plugin
     */
    public function get_plugin_name() 
    {
        return $this->plugin_name;
    }

    /**
     * The reference to the class that orchestrates the hooks with the plugin.
     *
     * @since 1.0.0
     *
     * @return Adreno_Loader orchestrates the hooks of the plugin
     */
    public function get_loader() 
    {
        return $this->loader;
    }

    /**
     * Retrieve the version number of the plugin.
     *
     * @since 1.0.0
     *
     * @return string the version number of the plugin
     */
    public function get_version() 
    {
        return $this->version;
    }
}
