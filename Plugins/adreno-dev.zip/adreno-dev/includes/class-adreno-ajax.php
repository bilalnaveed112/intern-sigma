<?php


/**
 * The admin-ajax-specific functionality of the plugin.
 *
 * @package Adreno
 * @see     https://adreno.ai
 * @since   1.0.0
 */

/**
 * The admin-ajax-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @author Sohaib Muzammal <sohaib.muzammal@gmail.com>
 */

class Adreno_Ajax
{

    /**
     * The ID of this plugin.
     *
     * @since 1.0.0
     *
     * @var string the ID of this plugin
     */
    private $_plugin_name;

    /**
     * The version of this plugin.
     *
     * @since 1.0.0
     *
     * @var string the current version of this plugin
     */
       private $_version;

    /**
     * Initialize the class and set its properties.
     *
     * @param string $plugin_name the name of this plugin
     * @param string $version     the version of this plugin
     *
     * @since 1.0.0
     */
    public function __construct( $plugin_name, $version ) {
        $this->plugin_name = $plugin_name;
        $this->version     = $version;

    }

    /**
     * Function for checking is user activated.
     *
     * @since 1.0.0
     */
    public function adrenoai_user_validation()
    {
        $nonce = $_POST['security'];
        if (!wp_verify_nonce($nonce, 'adrenoai_security_nonce')) {
            exit();
        }

        $adrenoai_activation_key = get_option('adrenoai_activation_key');
        $adrenoai_user_credits = get_option('adrenoai_user_credits');
        $adrenoai_user_image_credits = get_option('adrenoai_user_image_credits');
        if ($adrenoai_activation_key) {
            $response = [
                'status' => 'registered',
                'user_key' => $adrenoai_activation_key,
                'user_credits' => $adrenoai_user_credits,
                'user_image_credits' => $adrenoai_user_image_credits,
            ];
            echo json_encode($response);
        } else {
            $response = [
                'status' => 'unregistered',
            ];
            echo json_encode($response);
        }
        exit;
    }

    /**
     * Function for auto generating content.
     *
     * @since 1.0.0
     */
    public function adrenoai_auto_generate_content()
    {
        $nonce = $_POST['security'];
        if (!wp_verify_nonce($nonce, 'adrenoai_security_nonce')) {
            exit();
        }

        $keyword_value  = sanitize_text_field($_POST['adrenoai_content_keyword']);
        $words_limits   = sanitize_text_field($_POST['adrenoai_content_limits']);
        $h1_tags_counts = sanitize_text_field($_POST['h1_tags_counts']);
        $h2_tags_counts = sanitize_text_field($_POST['h2_tags_counts']);
        $h3_tags_counts = sanitize_text_field($_POST['h3_tags_counts']);
        $h4_tags_counts = sanitize_text_field($_POST['h4_tags_counts']);
        $h5_tags_counts = sanitize_text_field($_POST['h5_tags_counts']);
        $h6_tags_counts = sanitize_text_field($_POST['h6_tags_counts']);

        if ($words_limits == '') {
            $words_limits = 100;
        }

        $adrenoai_activation_key = get_option('adrenoai_activation_key');
        $adrenoai_user_credits = get_option('adrenoai_user_credits');

        if (!empty($adrenoai_activation_key)) {
            $response = wp_remote_post(
                Adreno_Paths::$platform_url.Adreno_Paths::$platform_api_end_point.'send-inputs',
                [
                    'timeout' => 1000,
                    'body' => [
                        'keyword' => $keyword_value,
                        'word_limit' => $words_limits,
                        'key' => $adrenoai_activation_key,
                        'h1_tags_counts' => $h1_tags_counts,
                        'h2_tags_counts' => $h2_tags_counts,
                        'h3_tags_counts' => $h3_tags_counts,
                        'h4_tags_counts' => $h4_tags_counts,
                        'h5_tags_counts' => $h5_tags_counts,
                        'h6_tags_counts' => $h6_tags_counts,
                    ],
                ]
            );

            if (is_wp_error($response)) {
                // Handle the error
                return false;
            } else {
                // Handle the success
                $responsed_data = json_decode(wp_remote_retrieve_body($response));

            }

            // Display Response
            echo trim($responsed_data);
        } else {
            $adrenoai_response = _e('Please go to Adreno Dashboard and Registered Your Key', 'adreno');
            echo $adrenoai_response;
        }
        exit;
    }


    /**
     * Function for key vaidation.
     *
     * @since 1.0.0
     */
    public function adrenoai_key_validation()
    {
        $nonce = $_POST['security'];
        if (!wp_verify_nonce($nonce, 'adrenoai_security_nonce')) {
            exit();
        }

        $adrenoai_act_key = sanitize_text_field($_POST['adrenoai_act_key']);
        $adrenoai_user_key = get_option('adrenoai_activation_key');

        $response = wp_remote_post(
            Adreno_Paths::$platform_url.Adreno_Paths::$platform_api_end_point.'key_validation',
            [
                'timeout' => 100,
                'body' => [
                    'key' => $adrenoai_act_key,
                ],
            ]
        );

        if (is_wp_error($response)) {
            // return false;
            $adrenoai_response = $response;
        } else {
            $responsed_data = json_decode(wp_remote_retrieve_body($response));
        }

        if ('registered' == $responsed_data->status) {
            if ('' == $adrenoai_user_key) {
                update_option('adrenoai_activation_key', $adrenoai_act_key);
                update_option('adrenoai_user_credits', $responsed_data->user_text_credits);
                update_option('adrenoai_user_image_credits', $responsed_data->user_image_credits);
                $adrenoai_response = _e('Your Key is registered', 'adreno');
            }
        } elseif (0 == $responsed_data) {
            $adrenoai_response = _e('Your Key is invalid', 'adreno');
        }
        echo $adrenoai_response;
        exit;
    }


    /**
     * Function for delete registered key.
     *
     * @since 1.0.0
     */
    public function adrenoai_delete_registered_key()
    {
        $nonce = $_POST['security'];
        if (!wp_verify_nonce($nonce, 'adrenoai_security_nonce')) {
            exit();
        }

        $adrenoai_delete_key     = delete_option('adrenoai_activation_key');
        $adrenoai_delete_credits = delete_option('adrenoai_user_credits');
        $adrenoai_delete_credits = delete_option('adrenoai_user_image_credits');
        if ($adrenoai_delete_key) {
            $adrenoai_response = _e('Your Key is Deactivated.', 'adreno');
        }
        echo $adrenoai_response;
        exit;
    }


    /**
     * Function for Update text credits.
     *
     * @since 1.0.0
     */
    public function adrenoai_update_text_credits()
    {
        $nonce = $_POST['security'];
        if (!wp_verify_nonce($nonce, 'adrenoai_security_nonce')) {
            exit();
        }

        $adrenoai_user_key = get_option('adrenoai_activation_key');

        $response = wp_remote_post(
            Adreno_Paths::$platform_url.Adreno_Paths::$platform_api_end_point.'key_validation',
            [
                'timeout' => 100,
                'body' => [
                    'key' => $adrenoai_user_key,
                ],
            ]
        );

        if (is_wp_error($response)) {
            // return false;
            $adrenoai_response = $response;
        } else {
            $responsed_data = json_decode(wp_remote_retrieve_body($response));
        }

        if ('registered' == $responsed_data->status) {
            update_option('adrenoai_user_credits', $responsed_data->user_text_credits);
            update_option('adrenoai_user_image_credits', $responsed_data->user_image_credits);
            $adrenoai_response = [
                'status' => 'available',
                'adreno_user_text_credits' => $responsed_data->user_text_credits,
                'adreno_user_image_credits' => $responsed_data->user_image_credits,
            ];
        } elseif (0 == $responsed_data) {
            $adrenoai_response = [
                'status' => 'unavailable',
                'adreno_user_text_credits' => '0',
                'adreno_user_image_credits' => '0',
            ];
            echo $adrenoai_response;
        }
        echo json_encode($adrenoai_response);
        exit;
    }

    /**
     * Function for Update User About Info.
     *
     * @since 1.0.0
     */

    public function adrenoai_update_about_info()
    {
        $nonce = $_POST['security'];
        if (!wp_verify_nonce($nonce, 'adrenoai_security_nonce')) {
            exit();
        }
        
        $adreno_organization_name = sanitize_text_field($_POST['adreno_organization_name']);
        $adreno_industry_name     = sanitize_text_field($_POST['adreno_industry_name']);
        $adreno_product           = sanitize_text_field($_POST['adreno_product']);
        $adreno_related_keywords  = sanitize_text_field($_POST['adreno_related_keywords']);

        update_option('adreno_organization_name', $adreno_organization_name);
        update_option('adreno_industry_name',     $adreno_industry_name);
        update_option('adreno_product',           $adreno_product);
        update_option('adreno_related_keywords',  $adreno_related_keywords);

        $response = [
            'organization_name' => $adreno_organization_name,
            'industry_name' => $adreno_industry_name,
            'product' => $adreno_product,
            'related_keywords' => $adreno_related_keywords
        ];
        echo json_encode($response);
        exit;
    }

    /**
     * Function for Suggest Keywords.
     *
     * @since 1.0.0
     */

    public function adrenoai_suggest_keywords()
    {

        $nonce = $_POST['security'];
        if (!wp_verify_nonce($nonce, 'adrenoai_security_nonce')) {
            exit();
        }

        $adrenoai_user_key        = get_option('adrenoai_activation_key');
        $adreno_organization_name = get_option('adreno_organization_name');
        $adreno_industry_name     = get_option('adreno_industry_name');
        $adreno_product           = get_option('adreno_product');
        $adreno_related_keywords  = get_option('adreno_related_keywords');

        if ($adrenoai_user_key != '' && $adreno_organization_name != '' && $adreno_industry_name != '' && $adreno_product != '' && $adreno_related_keywords != '') {

            $response = wp_remote_post(
                Adreno_Paths::$platform_url.Adreno_Paths::$platform_api_end_point.'keyword_suggestion',
                [
                        'timeout' => 100,
                        'body' => [
                               'key'               => $adrenoai_user_key,
                               'organization_name' => $adreno_organization_name,
                               'industry_name'     => $adreno_industry_name,
                               'product'           => $adreno_product,
                               'related_keywords'  => $adreno_related_keywords,
                        ],
                ]
            );

            if (is_wp_error($response)) {
                // return false;
                $adrenoai_response = $response;
            } else {
                $responsed_data = json_decode(wp_remote_retrieve_body($response));
            }

        } else {
            $responsed_data = _e('Go to About page and add information', 'adreno');
        }

        echo $responsed_data;
        exit;

    }

    /**
     * Function for Image Generation.
     *
     * @since 1.0.0
     */

    public function adrenoai_image_generation() 
    {
        $nonce = $_POST['security'];
        if (!wp_verify_nonce($nonce, 'adrenoai_security_nonce')) {
            exit();
        }

        $adrenoai_user_key = get_option('adrenoai_activation_key');

        if (!empty($adrenoai_user_key)) {

            $adreno_image_generation_keyword = sanitize_text_field($_POST['keywords']);
            $adreno_image_generation_size = sanitize_text_field($_POST['size']);
    
    
            $response = wp_remote_post(
                Adreno_Paths::$platform_url.Adreno_Paths::$platform_api_end_point.'image_generation',
                [
                    'timeout' => 100,
                    'body' => [
                        'key'                    => $adrenoai_user_key,
                        'image_related_keywords' => $adreno_image_generation_keyword,
                        'image_related_size'     => $adreno_image_generation_size,
                    ],
                ]
            );
    
            if (is_wp_error($response)) {
                return false;
            } else {

                $responsed_data = json_decode(wp_remote_retrieve_body($response));
                $adrenoai_responsed = [
                    'status' => 'success',
                    'image_url' => $responsed_data,
                ];
            }    
        } else {
            $adrenoai_responsed = [
                'status' => 'error',
            ];
        }
        echo json_encode($adrenoai_responsed);
        exit;
    }

    /**
     * Function for adding generated image to featured image.
     *
     * @since 1.0.0
     */
    public function adrenoai_add_featured_image()
    {

        $nonce = $_POST['security'];
        if (!wp_verify_nonce($nonce, 'adrenoai_security_nonce')) {
            exit();
        }

        $adreno_image_generation_url = $_POST['adrenoai_image_url'];
        $adrenoai_current_page_id = $_POST['adrenoai_current_page_id'];
        $adrenoai_image_alt = $_POST['adrenoai_image_alt'];
        $adrenoai_image_title = $_POST['adrenoai_image_title'];

        if ($adrenoai_current_page_id) {

            $attachment_id = media_sideload_image($adreno_image_generation_url, $adrenoai_current_page_id, $adrenoai_image_title, 'id');

            if (!is_wp_error($attachment_id)) {

                set_post_thumbnail($adrenoai_current_page_id, $attachment_id);
                update_post_meta($attachment_id, '_wp_attachment_image_alt', $adrenoai_image_alt);

                echo _e('successfully set as featured image and uploaded in media. Please reload page to see image', 'adreno');

            } else {
                echo _e('Error adding featured image: ', 'adreno') . $attachment_id->get_error_message();
            }
        } else {
            echo _e('No post ID found.', 'adreno');
        }
        exit;
    }


    /**
     * Function for adding generated Title for image.
     *
     * @since 1.0.0
     */

    public function adrenoai_create_auto_title()
    {

        $nonce = $_POST['security'];
        if (!wp_verify_nonce($nonce, 'adrenoai_security_nonce')) {
            exit();
        }

        $adreno_image_generation_url = $_POST['adrenoai_image_url'];
        $adrenoai_user_key = get_option('adrenoai_activation_key');

        $response = wp_remote_post(
            Adreno_Paths::$platform_url.Adreno_Paths::$platform_api_end_point.'image_auto_title',
            [
                'timeout' => 100,
                'body' => [
                        'key'                    => $adrenoai_user_key,
                        'image_auto_title'       => $adreno_image_generation_url,
                ],
            ]
        );

        if (is_wp_error($response)) {
            // return false;
            $adrenoai_response = $response;
        } else {
            $responsed_data = json_decode(wp_remote_retrieve_body($response));
        }
        echo $responsed_data;
        exit;
    }


    /**
     * Function for generated alt for image.
     *
     * @since 1.0.0
     */

    public function adrenoai_create_auto_alt()
    {

        $nonce = $_POST['security'];
        if (!wp_verify_nonce($nonce, 'adrenoai_security_nonce')) {
            exit();
        }

        $adreno_image_generation_url = $_POST['adrenoai_image_url'];
        $adrenoai_user_key = get_option('adrenoai_activation_key');

        $response = wp_remote_post(
            Adreno_Paths::$platform_url.Adreno_Paths::$platform_api_end_point.'image_auto_alt',
            [
                'timeout' => 100,
                'body' => [
                        'key'            => $adrenoai_user_key,
                        'image_auto_alt' => $adreno_image_generation_url,
                ],
            ]
        );

        if (is_wp_error($response)) {
            // return false;
            $adrenoai_response = $response;
        } else {
            $responsed_data = json_decode(wp_remote_retrieve_body($response));
        }
        echo $responsed_data;
        exit;

    }

    public function adrenoai_add_image_to_media_library()
    {

        $nonce = $_POST['security'];
        if (!wp_verify_nonce($nonce, 'adrenoai_security_nonce')) {
            exit();
        }

        $adreno_image_generation_url = $_POST['adrenoai_image_url'];
        $adrenoai_image_alt          = $_POST['adrenoai_image_alt'];
        $adrenoai_image_title        = $_POST['adrenoai_image_title'];


            require_once(ABSPATH . 'wp-admin/includes/file.php');
            require_once(ABSPATH . 'wp-admin/includes/image.php');
            $temp_file = download_url($adreno_image_generation_url);

        if (is_wp_error($temp_file)) {
            var_dump($temp_file);
            exit;
        }

            $adrenoai_image_file = array(
                'name'     => basename($adreno_image_generation_url),
                'type'     => mime_content_type($temp_file),
                'tmp_name' => $temp_file,
                'size'     => filesize($temp_file),
            );
            $adrenoai_image_load = wp_handle_sideload(
                $adrenoai_image_file,
                array(
                    'test_form'   => false
                )
            );

        if (!empty($adrenoai_image_load['error'])) {

            $response = [
                'status' => 'error',
                'error_message' => $adrenoai_image_load['error'],
            ];
            echo json_encode($response);

            exit;
        } 


            $adrenoai_attachment_id = wp_insert_attachment(
                array(
                    'guid'           => $adrenoai_image_load[ 'url' ],
                    'post_mime_type' => $adrenoai_image_load[ 'type' ],
                    'post_title'     => ($adrenoai_image_title) ? $adrenoai_image_title : '',
                    'post_excerpt'   => ($adrenoai_image_alt) ? $adrenoai_image_alt : '',
                    'post_content'   => '',
                    'post_parent'    => 0,
                    'post_status'    => 'inherit',
                ),
                $adrenoai_image_load[ 'file' ]
            );

            wp_update_attachment_metadata(
                $adrenoai_attachment_id,
                wp_generate_attachment_metadata($adrenoai_attachment_id, $adrenoai_image_load[ 'file' ])
            );

        $adrenoai_uploaded_image_url = admin_url('upload.php').'?item='.$adrenoai_attachment_id;

        $response_message = __('Successfully Uploaded image in media libray. Here is the link : ');

        $response = [
            'status' => 'success',
            'success_message' => $response_message.$adrenoai_uploaded_image_url,
        ];
        echo json_encode($response);
        exit;
    }


}








