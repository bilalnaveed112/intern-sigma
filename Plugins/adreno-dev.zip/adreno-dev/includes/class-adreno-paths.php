<?php
/**
 * File containing all the hardcoded paths
 *
 * These paths will be used in plugin for different links
 *
 * @since      1.0.0
 * @package    Adreno
 * @subpackage Adreno/includes
 * @author     Sohaib Muzammal <sohaib.muzammal@gmail.com>
 */
class Adreno_Paths {

	public static $platform_url                = 'https://lookwearfeel.com/LWF';
	public static $platform_account_end_point  = '/my-account/';
	public static $platform_register_end_point = '/my-account/';
	public static $platform_plans_end_point    = '/shop/';
	public static $platform_api_end_point      = '/wp-json/auto-content-generator/v1/';

}
