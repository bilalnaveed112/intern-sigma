<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @package Adreno
 * @see     https://adreno.ai
 * @since   1.0.0
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @author Sohaib Muzammal <sohaib.muzammal@gmail.com>
 */
class Adreno_Admin
{

    /**
     * The ID of this plugin.
     *
     * @since 1.0.0
     *
     * @var string the ID of this plugin
     */
       private $_plugin_name;

    /**
     * The version of this plugin.
     *
     * @since 1.0.0
     *
     * @var string the current version of this plugin
     */
       private $_version;

    /**
     * Initialize the class and set its properties.
     *
     * @param string $plugin_name the name of this plugin
     * @param string $version     the version of this plugin
     *
     * @since 1.0.0
     */
    public function __construct( $plugin_name, $version ) {
        $this->plugin_name = $plugin_name;
        $this->version     = $version;

        add_action('admin_head', array( $this, 'adrenoai_icon_display' ));
    }

    /**
     * Register the stylesheets for the admin area.
     *
     * @since 1.0.0
     */
    public function enqueue_styles() 
    {
        /*
         * This function is provided for demonstration purposes only.
         *
         * An instance of this class should be passed to the run() function
         * defined in Adreno_Loader as all of the hooks are defined
         * in that particular class.
         *
         * The Adreno_Loader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.
         */

        wp_enqueue_style($this->plugin_name, plugin_dir_url(__FILE__) . 'css/adreno-admin.css', array(), $this->version, 'all');
    }

    /**
     * Register the JavaScript for the admin area.
     *
     * @since 1.0.0
     */
    public function enqueue_scripts() 
    {
        /*
         * This function is provided for demonstration purposes only.
         *
         * An instance of this class should be passed to the run() function
         * defined in Adreno_Loader as all of the hooks are defined
         * in that particular class.
         *
         * The Adreno_Loader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.
         */

        wp_enqueue_script($this->plugin_name, plugin_dir_url(__FILE__) . 'js/adreno-admin.js', array( 'jquery' ), $this->version, false);
    }

    /**
     * Register the JavaScript for the content generation with Ajax.
     *
     * @since 1.0.0
     */

    public function adrenoai_enque_content_generator() 
    {
        $screen = get_current_screen();
        if (strpos($screen->base, 'post') !== false || strpos($screen->base, 'adrenoai') !== false) {
            wp_register_script('adrenoai_content_ajax_file', plugin_dir_url(__FILE__) . 'js/adrenoai_content_generator.js', array( 'jquery' ), '1.1', false);
            wp_enqueue_script('adrenoai_content_ajax_file');

            $localize = array(
                'ajaxurl'  => admin_url('admin-ajax.php'),
                'security' => wp_create_nonce('adrenoai_security_nonce'),
            );
            wp_localize_script('adrenoai_content_ajax_file', 'adrenoai_ajax_parameters', $localize);
        }
    }

    /**
     * Function for displaying icon in admin side.
     *
     * @since 1.0.0
     */

    public function adrenoai_icon_display()
    {
        $screen = get_current_screen();
        if (strpos($screen->base, 'post') !== false ) {
            ?>
            <!-- Adreno Icons -->
            <div class="adrenoai-popup-open-close-icon" id="adrenoai-popup-open-close-icon">
                <div id="adrenoai_icon" class="adrenoai_icon">
                    <h2 class="adrenoai_title"><span><img class="adrenoai_dashoard_logo" src="<?php echo plugins_url('adreno-dev/admin/images/logo.png'); ?>" alt=""></span></h2>
                </div>
                <span><img class="adrenoai_dashoard_logo" src="<?php echo plugins_url('adreno-dev/admin/images/popup-close.png'); ?>" alt=""></span>
            </div>

            <!-- Adreno Popup -->
            <div class="adrenoai_popup">
                <div class="adrenoai-popup-heading-section">
                    <h2 class="adrenoai_title"><?php esc_html_e('Adreno Intelligence Center', 'adreno'); ?></h2>
                    <div class="adrenoai-select-optios">
                        <select name="adrenoai_optios" class="adrenoai_optios" id="adrenoai_options">
                            <option value="adrenoai_services"><h3><?php esc_html_e('Select a model', 'adreno'); ?></h3></option>
                            <option value="adreno_ai_content_generation"><h3><?php esc_html_e('Content generation', 'adreno'); ?></h3></option>
                            <option value="adreno_ai_image_generation"><h3><?php esc_html_e('Image generation', 'adreno'); ?></h3></option>
                            <option value="adreno_ai_head_tag_generation"><h3><?php esc_html_e('Heading tag generation', 'adreno'); ?></h3></option>
                            <option value="adreno_ai_tag_categorise"><h3><?php esc_html_e('Automated tagging and categorization', 'adreno'); ?></h3></option>
                        </select>
                    </div>
                </div>
                <!-- Adreno Popup Main Page -->
                <div class="adrenoai_services_options">
                    <div class="adrenoai-notes-aria">
                        <p class="adrenoai-note"><?php _e('You can find details on each of the modules below. Click on the module to get a brief description on it. You can refer our documentation to read more on each module', 'adreno'); ?></p>
                    </div>
                    <div class="adrenoai-services-section">
                        <ul class="adrenoai-services">
                            <li class="">
                                <span><img src="<?php echo plugins_url('adreno-dev/admin/images/content.png'); ?>" alt=""></span>
                                <?php _e('Content Generation', 'adreno'); ?>
                            </li>
                            <li class="">
                                <span><img src="<?php echo plugins_url('adreno-dev/admin/images/image.png'); ?>" alt=""></span>
                                <?php _e('Image Genration', 'adreno'); ?>
                            </li>
                            <li class="">
                                <span><img src="<?php echo plugins_url('adreno-dev/admin/images/seo.png'); ?>" alt=""></span>
                                <?php _e('SEO', 'adreno'); ?>
                            </li>
                            <li class="">
                                <span><img src="<?php echo plugins_url('adreno-dev/admin/images/translate.png'); ?>" alt=""></span>
                                <?php _e('Translation', 'adreno'); ?>
                            </li>
                            <li class="">
                                <span><img src="<?php echo plugins_url('adreno-dev/admin/images/ecommerce.png'); ?>" alt=""></span>
                                <?php _e('E-Commerce', 'adreno'); ?>
                            </li>
                            <li class="">
                                <span><img src="<?php echo plugins_url('adreno-dev/admin/images/email.png'); ?>" alt=""></span>
                                <?php _e('Marketing Email', 'adreno'); ?>
                            </li>
                        </ul>
                    </div>
                </div>
                <!--End Adreno Popup Main Page -->
                
                <!-- Content Generation Form -->
                    <div class="adrenoai-content-generation-aria adrenoai_services adrenoai_hide">
                        <h2 class="adrenoai-content-generation-heading">
                            <span class="dashicons dashicons-feedback"></span>
                            <?php _e('Content Generation', 'adreno'); ?>
                        </h2>
                        <form action="" method="post" class="adrenoai-content-form" id="adrenoai_content_form">
                            <div class="adrenoai_content_keyword_input">
                                <label for="adrenoai_content_keyword"><?php _e('Comma separated keywords', 'adreno'); ?></label>
                                <input name="adrenoai_content_keyword" id="adrenoai_content_keyword" class= "adrenoai_content_keyword" type="text">
                                <div class="adrenoai_content_keyword_inputs_message">
                                    <input type="hidden" name="submit" id="adrenoai_content_inputs_empty" value="<?php _e('Go to About page and add information', 'adreno'); ?>">
                                    <input type="button" name="submit" id="adrenoai_content_inputs" value="<?php _e('Suggest me keywords', 'adreno'); ?>">
                                    <p class="adrenoai_content_keyword_inputs_error"><?php _e('Please Enter Keyword', 'adreno'); ?></p>
                                </div>
                                <div class="adrenoai_loading" id="adrenoai_loading_suggestion_keywords">Loading&#8230;</div>
                            </div>

                            <!-- Heading Tags -->
                            <div class="adrenoai-contentheading-tags">
                                <p><?php _e('Select the heading tags', 'adreno'); ?></p>
                                <div class="adrenoai-content-tags">
                                    <div>
                                        <label for="h1_tag">H1</label>
                                        <input id="h1_tag" type="number" min="0" max="99" value="0">
                                    </div>
                                    <div>
                                        <label for="h2_tag">H2</label>
                                        <input id="h2_tag" type="number" min="0" max="99" value="0">
                                    </div>
                                    <div>
                                        <label for="h3_tag">H3</label>
                                        <input id="h3_tag" type="number" min="0" max="99" value="0">
                                    </div>
                                    <div>
                                        <label for="h4_tag">H4</label>
                                        <input id="h4_tag" type="number" min="0" max="99" value="0">
                                    </div>
                                    <div>
                                        <label for="h5_tag">H5</label>
                                        <input id="h5_tag" type="number" min="0" max="99" value="0">
                                    </div>
                                    <div>
                                        <label for="h6_tag">H6</label>
                                        <input id="h6_tag" type="number" min="0" max="99" value="0">
                                    </div>
                                </div>
                            </div>
                            <!-- End Heading Tags -->

                                <!-- Set Words Limit -->
                            <div class="adrenoai-generated-content-aria">
                                <div class="adrenoai-word-count-limit-aria">
                                    <label for="adrenoai_word_count_limit"><?php _e('Set Word count limit', 'adreno'); ?></label>
                                    <div class="adrenoai-word-count-button">
                                        <input type="number" name="adrenoai_word_count_limit" class="adrenoai-word-count-limit" id="" value="100">
                                        <p class="adrenoai_word_count_limit_empty adrenoai_hide" id=""><?php _e('You have not entered any value', 'adreno') ?></p>
                                        <button type="button" id="adrenoai_token_required"><?php _e('Calculate estimated token requires', 'adreno'); ?></button>
                                    </div>
                                    <input type="hidden" name="adrenoai_estimate_word_count" class="adrenoai_estimate_word_count" value="<?php _e('Estimated credits required are: ', 'adreno') ?>">
                                    <strong id="adrenoai_text_credits_require"></strong>
                                </div>
                                <div class="adrenoai-generated-content-textaria">
                                    <div class="adrenoai-generated-content-label">
                                        <label for="adrenoai-generated-content-text"><?php _e('Generated content', 'adreno'); ?></label>
                                        <input type="hidden" id="adrenoai_content_text_copied" value="<?php _e('Copied', 'adreno'); ?>">
                                        <input type="submit" id="adrenoai-regenerate-content-button" value ="<?php _e('Generate', 'adreno'); ?>" />
                                    </div>

                                    <!-- Text Area -->
                                    <div class="adrenoai-generated-text">
                                        <div class="adrenoai_loading" id="adrenoai_content_loading">Loading&#8230;</div>
                                        <p class="adrenoai_content_content_box" name="adrenoai-generated-content-text" id="" ></p>
                                        <div class="adrenoai-content-copy-icon">
                                            <span><img src="<?php echo plugins_url('adreno-dev/admin/images/copy.png'); ?>" alt=""></span>
                                            <span class="adrenoai_copy_message dashicons" id="adrenoai_copy_message"></span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </form>
                    </div>
                    <!-- End Content Generation Form -->


                    <!-- Image Generation Form -->
                    <div class="adreno_ai_image_generation adrenoai_services adrenoai_hide">
                        <div class="adrenoai-image-generation-heading">
                            <img src="<?php echo plugins_url('adreno-dev/admin/images/image.png'); ?>" alt="">
                            <h2><?php esc_html_e('Image Generation', 'adreno'); ?></h2>
                        </div>
                        <div class="adrenoai-image-generation-form-area">

                            <form action="" method="post" id="adrenoai_image_gen_form">

                                <div class="adrenoai-keyword-image-generation">

                                    <label for=""><?php _e('Add keywords to generate image', 'adreno'); ?></label>
                                    <p><?php _e('Add in keywords that are relevent to your topic to generate image', 'adreno'); ?></p>
                                    <input type="text" name="" id="adrenoai_image_input_keyword" class= "">
                                    <p class="adrenoai-image-form-error-message adrenoai_hide" id="adrenoai-image-form-error-message"><?php _e('Please Enter Keyword', 'adreno'); ?></p>

                                    <div class="adrenoai-keyword-image-buttons">
                                        <input type="hidden" name="" id="adrenoai_conten_keyword_empty" value="<?php _e('You do not have keywords.Click on suggest keywords', 'adreno'); ?>">
                                        <button type="button" class="adrenoai_image_copy_keywords"><?php _e('Copy from content generator keywords', 'adreno'); ?></button>
                                        <div class="adrenoai_loading" id="adrenoai_loading_image_suggestion_keywords">Loading&#8230;</div>
                                        <button type="button" class="adrenoai_image_keyword_suggest"><?php _e('Suggest keywords', 'adreno'); ?></button>
                                    </div>

                                    <div class="adrenoai-image-generation-sizes">
                                        <div class="adrenoai-image-generation-sizes-option">
                                            <input type="radio" name="adrenoai-image-size" id="" value="small" checked>
                                            <label for="adrenoai-image-size"><?php _e('Small', 'adreno'); ?></label>
                                        </div>
                                        <div class="adrenoai-image-generation-sizes-option">
                                            <input type="radio" name="adrenoai-image-size" id="" value="medium">
                                            <label for="adrenoai-image-size"><?php _e('Medium', 'adreno'); ?></label>
                                        </div>
                                        <div class="adrenoai-image-generation-sizes-option">
                                            <input type="radio" name="adrenoai-image-size" id="" value="large">
                                            <label for="adrenoai-image-size"><?php _e('Large', 'adreno'); ?></label>
                                        </div>
                                    </div>
                                </div>

                                <div class="adrenoai-image-generation">

                                    <div class="adrenoai-generateed-image-label-button">
                                        <label for=""><?php _e('Generated Image', 'adreno'); ?></label>
                                        <input type="submit" class="adrenoai-regenerate-image-button" value ="<?php _e('Generate', 'adreno'); ?>">
                                    </div>

                                    <div class="adrenoai-generateed-image">
                                        <div class="adrenoai_loading" id="adrenoai_loading_image_suggestion_div">Loading&#8230;</div>
                                        <img id="adrenoai_auto_generated_image" src="" alt="">
                                        <input type="hidden" id="adrenoai_empty_act_key" value="<?php _e('Please go to Adreno Dashboard and Registered Your Key', 'adreno'); ?>">
                                        <p id="adrenoai-generateed-image_p"></p>
                                    </div>

                                    <div class="adrenoai_image_saving_options">

                                        <!-- Options for featured Image or Media Library -->
                                        <div>
                                            <select name="" id="adrenoai_image_saving_select_options" class="adrenoai-image-generation-radio-buttons">
                                                <option value=""><?php _e('Please choose how to save image', 'adreno'); ?></option>
                                                <option value="featured_image"><?php _e('media library and set as featured image', 'adreno'); ?></option>
                                                <option value="media_library"><?php _e('media library only', 'adreno'); ?></option>
                                            </select>

                                        </div>
                                        <!-- End Options for featured Image or Media Library -->

                                        <div class="adrenoai_image_title_alt_radio_buttons">
                                            <div>
                                                <div class="adrenoai-image-generation-radio-buttons">
                                                    <input type="radio" name="adrenoai_image_title" id="adrenoai_image_title" value ="custom">
                                                    <label for="adrenoai_image_title"><?php _e('Add title name for the image', 'adreno'); ?></label>
                                                </div>
                                                <div class="adrenoai-image-generation-custom-name" id="adrenoai_image_generation_alt">
                                                    <label for="adrenoai_image_custom_title"><?php _e('Enter title for image', 'adreno'); ?></label>
                                                    <input type="text" name="adrenoai_image_custom_title" id="adrenoai_image_custom_title" value ="">
                                                </div>
                                                <div class="adrenoai-image-generation-radio-buttons">
                                                    <input type="radio" name="adrenoai_image_title" id="adrenoai_image_title_auto" value ="auto">
                                                    <label for="adrenoai_image_title_auto"><?php _e('Auto add the title name (users text credits)', 'adreno'); ?></label>
                                                </div>
                                                <div class="adrenoai_auto_title">
                                                    <input type="text" id="adrenoai_auto_title_input" disabled>
                                                    <div class="adrenoai_loading" id="adrenoai_loading_image_auto_title">Loading&#8230;</div>
                                                    <button class="adrenoai_auto_title_confirmation"><?php _e('Click here to get auto title for image', 'adreno'); ?></button>
                                                </div>
                                            </div>
                                            <div class="adrenoai_image_media_library_options">
                                                <div class="adrenoai-image-generation-radio-buttons">
                                                    <input type="radio" name="adrenoai_image_alt_title" id="adrenoai_image_alt_title" value ="custom">
                                                    <label for="adrenoai_image_alt_title"><?php _e('Add alt tag for image', 'adreno'); ?></label>
                                                </div>
                                                <div class="adrenoai-image-generation-custom-name" id="adrenoai_image_generation_title">
                                                    <label for="adrenoai_image_alt_custom_title"><?php _e('Enter alternate tag for image', 'adreno'); ?></label>
                                                    <input type="text" name="adrenoai_image_alt_custom_title" id="adrenoai_image_custom_alt" value ="">
                                                </div>
                                                <div class="adrenoai-image-generation-radio-buttons">
                                                    <input type="radio" name="adrenoai_image_alt_title" id="adrenoai_image_alt_title_auto" value ="auto">
                                                    <label for="adrenoai_image_alt_title_auto"><?php _e('Auto add alt tag (users text credits)', 'adreno'); ?></label>
                                                </div>
                                                <div class="adrenoai_auto_alt">
                                                    <input type="text" id="adrenoai_auto_alt_input" disabled>
                                                    <div class="adrenoai_loading" id="adrenoai_loading_image_auto_alt">Loading&#8230;</div>
                                                    <button class="adrenoai_auto_alt_confirmation"><?php _e('Click here to get auto alt for image', 'adreno'); ?></button>
                                                </div>
                                            </div>
                                        </div>
                                    <!-- Featured Image Area -->
                                        <div class="adrenoai-add-image-buttons">
                                            <button type="button" class="adrenoai_add_featured_image"><?php _e('Add to featured image area', 'adreno'); ?></button>
                                            <input type="hidden" value="<?php echo get_the_ID(); ?>" id="adrenoai_current_page_id">
                                        </div>
                                    <!-- End Featured Image Area -->

                                    <!-- Save to Media Library Area -->
                                        <div class="adrenoai-image-generation-radio">    
                                            <div>
                                                <p>
                                                    <?php _e('To use this feature please allow svgs images to upload from your site', 'adreno') ?>
                                                </p>
                                            </div>
                                            <!-- Saving Button -->
                                            <div class="adrenoai-add-image-media-buttons">    
                                                <button type="button" class="adrenoai_image_adding_in_library"><?php _e('Add to media library', 'adreno'); ?></button>
                                            </div>
                                        </div>
                                    </div> 
                                    <!-- End Save to Media Library Area -->

                                    <!-- Image Saving Loader -->
                                    <div id="adrenoai_loading_image_saving_loading">
                                        <div class="adrenoai_loading" id="adrenoai_loading_image_added">Loading&#8230;</div>
                                    </div>
                                    <!-- End Image Saving Loader -->

                                    <!-- Error or Success Messages -->
                                    <p class="adrenoai-add-image-buttons_success"></p>
                                    <p class="adrenoai-add-image-buttons_error"></p>
                                    <p class="adrenoai_image_empty_image adrenoai_hide"><?php _e('Image not found. Generate Image First', 'adreno'); ?></p>
                                    <!-- End Error or Success Messages -->
                                    
                                </div>
                            </form>
                        </div>
                    </div>
                    <!-- End Image Generation Form -->

                        <!-- Heading Tag Generation Form -->
                    <div class="adrenoai_heading_tag_form adrenoai_services adrenoai_hide">
                        <form action="" method="post" id="adrenoai_heading_tag_form">
                            <h2><?php esc_html_e('Heading Tag Generation', 'adreno'); ?></h2>
                            <div class="">
                                <label for=""><?php _e('Enter Your Subject Here', 'adreno'); ?></label>
                                <input name="" id="" class= "" type="text">
                            </div>
                            <input name="submit" id="" type="submit" value="Generate Heading Tags"><br>
                            <textarea id="" class="adrenoai_hide" rows="5"></textarea>
                        </form>
                    </div>

                    <!-- Automated Tagging and Categorization Form  -->
                    <div class="adrenoai_auto_tags_categories_form adrenoai_services adrenoai_hide">
                        <form action="" method="post" id="adrenoai_auto_tags_categories_form" >
                            <h2><?php _e('Automated Tagging and Categorization', 'adreno'); ?></h2>
                            <div class="">
                                <label for=""><?php _e('Enter Your Subject Here', 'adreno'); ?></label>
                                <input name="" id="" class= "" type="text">
                            </div>
                            <input name="submit" id="" type="submit" value="Generate Heading Tags"><br>
                            <textarea id="" class="adrenoai_hide" rows="5"></textarea>
                        </form>
                    </div>

            </div>
            <?php
        }
    }

    /**
     * Function for displaying adrenoai page in settings.
     *
     * @since 1.0.0
     */

    public function adrenoai_setting_page() 
    {

        add_menu_page(
            'Adreno',                             // Page Title
            'Adreno',                             // Page Menu Title
            'manage_options',                     // Capability
            'adrenoai_dashboard',                 // Page Slug
            array( $this, 'adrenoai_dashoard_page' ),    // Page Function
            'dashicons-welcome-write-blog',
            3     // Icon
        );

        add_submenu_page(
            'adrenoai_dashboard',                      // Parent menu slug
            'Adreno AI About',                         // Subpage title
            'About',                                   // Subpage menu title
            'manage_options',                          // Capability required to access the subpage
            'adrenoai_about',                          // Subpage slug
            array( $this, 'adrenoai_about_page' )             // Function to display the subpage content
        );

    }


    /**
     * Function for displaying Adreno Dashboard Page.
     *
     * @since 1.0.0
     */

    public function adrenoai_dashoard_page() 
    {

        $adrenoai_user_key           = get_option('adrenoai_activation_key');
        $adrenoai_user_credits       = get_option('adrenoai_user_credits');
        $adrenoai_user_image_credits = get_option('adrenoai_user_image_credits');
        ?>
           
        <div class="adrenoai_dashoard_body">
            <div class="adrenoai_dashoard">
                <!-- Dashboard Menus -->
                <div class="adrenoai_dashoard_navbar">

                    <ul class="adrenoai_dashoard_navbar_menu">
                        <li>
                           <span><img class="adrenoai_dashoard_logo" src="<?php echo plugins_url( 'adreno-dev/admin/images/logo.png' ); ?>" alt=""></span>
                        </li>
                        <li>
                           <h2 class="adrenoai_active_page"><a href="<?php echo admin_url('admin.php?page=adrenoai_dashboard'); ?>"><?php esc_html_e('Dashoard', 'adreno'); ?></a></h2>
                        </li>
                        <li>
                           <h2><a href="<?php echo admin_url('admin.php?page=adrenoai_about'); ?>"><?php esc_html_e('About', 'adreno'); ?></a></h2>
                        </li>
                    </ul>
                </div>
                <!-- End Dashboard Menus -->
                <div class="adrenoai_dashoard_content">
                    <!-- Registration Form -->
                   <div class="adrenoai_registration_form adrenoai_hide">
                            <h3><?php esc_html_e('Registration', 'adreno'); ?></h3>
                            <div>
                                <p class="adrenoai_dashoard_content_note"><?php _e('Please enter your registration details to enable premium features add credits to your account.', 'adreno'); ?></p>
                                <a href="<?php echo Adreno_Paths::$platform_url . Adreno_Paths::$platform_account_end_point; ?>"><?php _e('Click Here to create/link your account', 'adreno'); ?></a>
                            </div>
                            <div class="adrenoai_dashoard_form_box">
                                <form action="" method="post" class="adrenoai_dashoard_form" >
                                    <input type="text" name="adrenoai_activation_key" class="adrenoai_dashoard_form_text" placeholder="<?php _e('ADD KEY HERE', 'adreno'); ?>">
                                    <input type="hidden" name="adrenoai_dashoard_user_registered" class="adrenoai_dashoard_user_registered" value="<?php _e('Your Key is registered', 'adreno'); ?>">
                                    <input type="hidden" name="adrenoai_dashoard_user_invalid" class="adrenoai_dashoard_user_invalid" value="<?php _e('Your Key is invalid', 'adreno'); ?>">
                                    <input type="hidden" name="adrenoai_dashoard_empty_key" class="adrenoai_dashoard_empty_key" value="<?php _e('You have not entered any key. Please enter your key and try again!', 'adreno'); ?>">
                                    <input type="submit" name="adrenoai_activation_submit" id="adrenoai_activation_submit" value="<?php _e('Register', 'adreno'); ?>" class="adrenoai_activation_submit button button-primary">
                                    <div class="adrenoai_loading">Loading&#8230;</div>
                                </form>
                            </div>
                            <div class="adrenoai_dashoard_credit_box">
                                <div class="adrenoai_dashoard_text">
                                    <h4><?php esc_html_e('Text Credits', 'adreno'); ?></h4>
                                    <p><a href="<?php echo Adreno_Paths::$platform_url . Adreno_Paths::$platform_account_end_point; ?>"><?php _e('Register to Update Credits', 'adreno'); ?></a></p>
                                </div>
                                <div class="adrenoai_dashoard_image">
                                    <h4><?php esc_html_e('Image Credits', 'adreno'); ?></h4>
                                    <p><a href="<?php echo Adreno_Paths::$platform_url . Adreno_Paths::$platform_account_end_point; ?>"><?php _e('Register to Update Credits', 'adreno'); ?></a></p>
                                </div>
                            </div>
                    </div> 
                    <!--Eng Registration Form -->

                        <!-- Unregistration Form -->
                        <div class="adrenoai_unregistration_form adrenoai_hide">
                            <div class="adrenoai_dashoard_form_box">
                                <form action="" method="post" class="adrenoai_dashoard_form" >
                                    <input type="text" name="adrenoai_activation_key" class="adrenoai_dashoard_form_text" disabled value="<?php echo ( $adrenoai_user_key ) ? $adrenoai_user_key : ''; ?>">
                                    <input type="submit" name="adrenoai_activation_submit" id="adrenoai_delete_activation_key" value="<?php _e('Unregister', 'adreno') ?>" class="button button-primary">
                                    <input type="hidden" name="adrenoai_activation_submit" id="adrenoai_delete_activation_message" value="<?php _e('Unregistered Successfully', 'adreno') ?>" class="button button-primary">
                                    <div id="adrenoai_loading_unregister" class="adrenoai_loading">Loading&#8230;</div>
                                </form>
                            </div>
                            <div class="adrenoai_dashoard_credit_box">
                                <div class="adrenoai_dashoard_text">
                                    <span class="dashicons dashicons-no adrenoai_dashoard_text_update"></span>
                                    <h4><?php esc_html_e('Text Credits', 'adreno'); ?></h4>
                                    <h1 class="adrenoai_dashoard_form_text_credit"><?php echo ( $adrenoai_user_credits ) ? $adrenoai_user_credits : ''; ?></h1>
                                    <div id="adrenoai_loading_text_update" class="adrenoai_loading">Loading&#8230;</div>
                            </div>
                                <div class="adrenoai_dashoard_image">
                                <span class="dashicons dashicons-no adrenoai_dashoard_image_update"></span>
                                    <h4><?php esc_html_e('Image Credits', 'adreno'); ?></h4>
                                    <h1 class="adrenoai_dashoard_form_image_credit">$<?php echo ( $adrenoai_user_image_credits ) ? $adrenoai_user_image_credits : ''; ?></h1>
                                    <div id="adrenoai_loading_image_update" class="adrenoai_loading">Loading&#8230;</div>
                                </div>
                                <div class="adrenoai_dashoard_get_cregits">
                                     <button class="button button-primary"><?php _e('Get Credits', 'adreno'); ?></button>
                                </div>
                            </div>
                        </div>
                        <!-- End Unregistration Form -->

                </div>
                <div class="notice notice-success is-dismissible adrenoai_hide" id="adrenoai_success"><p class="adrenoai_success"><?php _e('Setting Saved!', 'adreno'); ?></p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div>
                <div class="notice notice-error is-dismissible adrenoai_hide" id="adrenoai_errors"><p class="adrenoai_error"><?php _e('Error', 'adreno'); ?></p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div>
            </div>
        </div>

        <?php
    }


    /**
     * Function for displaying Adreno About Page.
     *
     * @since 1.0.0
     */


    public function adrenoai_about_page() 
    {


        $adreno_organization_name = get_option('adreno_organization_name');
        $adreno_industry_name     = get_option('adreno_industry_name');
        $adreno_product           = get_option('adreno_product');
        $adreno_related_keywords  = get_option('adreno_related_keywords');

        ?>

        <div class="adrenoai_about_body">
            <div class="adrenoai_dashoard">
                <!-- Menus -->
                <div class="adrenoai_dashoard_navbar">

                    <ul class="adrenoai_dashoard_navbar_menu">
                        <li>
                            <span><img class="adrenoai_dashoard_logo" src="<?php echo plugins_url('adreno-dev/admin/images/logo.png'); ?>" alt=""></span>
                        </li>
                        <li>
                            <h2><a href="<?php echo admin_url('admin.php?page=adrenoai_dashboard'); ?>"><?php esc_html_e('Dashoard', 'adreno'); ?></a></h2>
                        </li>
                        <li>
                            <h2 class="adrenoai_active_page"><a href="<?php echo admin_url('admin.php?page=adrenoai_about'); ?>"><?php esc_html_e('About', 'adreno'); ?></a></h2>
                        </li>
                    </ul>
                </div>
                <!-- About Page Form -->
                <div class="adrenoai_about_content">
                       <h3><?php _e('About', 'adreno'); ?></h3>
                       <p><?php _e('Add in information about you organization which helps Adreno generate information/content relevant to your site.', 'adreno'); ?><a href="" class="adrenoai_about_doc"><?php _e('Click here to refer the documentation', 'adreno'); ?></a></p>
                    <div class="adrenoai-dashoard-about-form">
                        <form action="">
                            <div class="adrenoai-dashoard-about-content">
                                <label for="organizationName"><?php _e('Organization Name', 'adreno'); ?></label>
                                <input type="text" name="organizationName" id="adrenoai_about_organization_name" value="<?php echo ( $adreno_organization_name ) ? $adreno_organization_name : ''; ?>">
                            </div>
                            <div class="adrenoai-dashoard-about-content">
                                <label for="industryName"><?php _e('Industry Name', 'adreno'); ?></label>
                                <input type="text" name="industryName" id="adrenoai_about_industry_name" value="<?php echo ( $adreno_industry_name ) ? $adreno_industry_name : ''; ?>">
                            </div>
                            <div class="adrenoai-dashoard-about-content">
                                <label for="describeProduct"><?php _e('Describe your product/business', 'adreno'); ?></label>
                                <textarea name="describeProduct" id="adrenoai_about_product" cols="40" rows="3"><?php echo ( $adreno_product ) ? $adreno_product : ''; ?></textarea>
                            </div>
                            <div class="adrenoai-dashoard-about-content">
                                <label for="releventKeywords"><?php _e('Add in keywords that are best relevent to your Business', 'adreno'); ?></label>
                                <input type="hidden" class="adrenoai_about_keyword_limit_message" value="<?php _e('Please Add Minimum 10 Keywords that are best relevent to your Business', 'adreno'); ?>">
                                <textarea name="releventKeywords" id="adrenoai_about_related_keywords" cols="40" rows="3"><?php echo ( $adreno_related_keywords ) ? $adreno_related_keywords : ''; ?></textarea>
                            </div>
                            <input type="hidden" id="adreno_unregister_user" value="<?php _e('Please go to Adreno Dashboard and Registered Your Key', 'adreno'); ?>">
                            <div class="adreno_about_submit_reset_buttons">
                                <input type="submit" class="button button-primary" id="adreno_about_page" value="<?php _e('Save', 'adreno'); ?>">
                                <input type="reset" class="adreno_about_page_reset"  value="<?php _e('Clear Form', 'adreno'); ?>">
                            </div>
                        </form>
                        <div class="notice notice-success is-dismissible adrenoai_hide" id="adrenoai_success"><p class="adrenoai_about_success"><?php _e('Setting Saved!', 'adreno'); ?></p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div>
                        <div class="notice notice-error is-dismissible adrenoai_hide" id="adrenoai_errors"><p class="adrenoai_about_error"><?php _e('Please Fill all the Fields', 'adreno'); ?></p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div>
                    </div>
                </div>
                <!-- End About Page Form -->
            </div>
        </div>
        <?php
    }
}
