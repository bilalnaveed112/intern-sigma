jQuery( document ).ready(
	function($) {

		var adrenoai_ajax_url = adrenoai_ajax_parameters.ajaxurl; //Ajax Url
		var adrenoai_security = adrenoai_ajax_parameters.security;

		function adrenoai_user_activation_check(){
			$( '.adrenoai_dashoard .notice-error' ).hide();
			$( '#adrenoai_errors' ).hide();
			var result;
			var data = {
				'action'                   : 'adrenoai_user_validation',
				'security'                 : adrenoai_security,
			}
			$.ajax(
				{
					url: adrenoai_ajax_url,
					type: 'post',
					data: data,
					success: function(res){
						var response = $.parseJSON( res );
						result       = response;
					},
					error: function(xhr, status, error) {
						console.log( status );
						$( '.adrenoai_error' ).html( error );
						$( '.adrenoai_dashoard .notice-error' ).show();
						$( '#adrenoai_errors' ).show();
					},
					async: false
				}
			);
			return result;
		}

		// if User Activated
		var adrenoai_user_activated = adrenoai_user_activation_check();

		if (adrenoai_user_activated.status == 'registered') {
			$( '.adrenoai_registration_form' ).hide();
			$( '.adrenoai_unregistration_form' ).show();
		} else {
			$( '.adrenoai_registration_form' ).show();
			$( '.adrenoai_unregistration_form' ).hide();
		}

		$( '.adrenoai-popup-open-close-icon' ).click(
			function() {
				$( '.adrenoai_popup' ).toggleClass('adrenoai_popup_active');
				$( '.adrenoai-popup-open-close-icon' ).toggleClass('adrenoai_popup_clicked');
				$( '.adrenoai_icon' ).toggle();
			}
		);


		$( '#adrenoai_options' ).on(
			'change',
			function(){

				var adrenoai_selected_option = $( '#adrenoai_options' ).val();

				if (adrenoai_selected_option == 'adreno_ai_content_generation') {
					$( '.adrenoai_services_options' ).hide();
					$( '.adrenoai_services' ).hide();
					$( '.adrenoai-content-generation-aria' ).show();
				} else if (adrenoai_selected_option == 'adreno_ai_image_generation') {
					$( '.adrenoai_services_options' ).hide();
					$( '.adrenoai_services' ).hide();
					$( '.adreno_ai_image_generation' ).show();
				} else if (adrenoai_selected_option == 'adreno_ai_head_tag_generation') {
					$( '.adrenoai_services_options' ).hide();
					$( '.adrenoai_services' ).hide();
					$( '.adrenoai_heading_tag_form' ).show();
				} else if (adrenoai_selected_option == 'adreno_ai_tag_categorise') {
					$( '.adrenoai_services_options' ).hide();
					$( '.adrenoai_services' ).hide();
					$( '.adrenoai_auto_tags_categories_form' ).show();
				} else if (adrenoai_selected_option == 'adrenoai_services') {
					$( '.adrenoai_services' ).hide();
					$( '.adrenoai_services_options' ).show();
				}

			}
		);

		// Token Required Estimation
		$( '#adrenoai_token_required' ).on(
			'click',
			function(e){
				e.preventDefault();
				let words_limits = $( '.adrenoai-word-count-limit' ).val();
				$( '#adrenoai_text_credits_require' ).empty();
				
				// 	// if Words limit is empty
				if (words_limits != '') {
					var total_credits = Math.round(1.333 * words_limits);
					$( '#adrenoai_text_credits_require' ).html(total_credits );
				} else {
					$( '.adrenoai_word_count_limit_empty' ).show();
					$( '#adrenoai_token_required' ).hide();
				}
			}
		);

		$( '.adrenoai-word-count-limit' ).on(
			'focus',
			function(){
				$( '#adrenoai_token_required' ).show();
				$( '.adrenoai_word_count_limit_empty' ).hide();
		});

		// End Token Required Estimation


		// Auto Content Generation 
		$( '#adrenoai-regenerate-content-button' ).on(
			'click',
			function(e){
				e.preventDefault();

				let h1_tags  = $( '#h1_tag' ).val();
				let h2_tags  = $( '#h2_tag' ).val();
				let h3_tags  = $( '#h3_tag' ).val();
				let h4_tags  = $( '#h4_tag' ).val();
				let h5_tags  = $( '#h5_tag' ).val();
				let h6_tags  = $( '#h6_tag' ).val();
				let keyword_value = $( '.adrenoai_content_keyword' ).val();
				let words_limits  = $( '.adrenoai-word-count-limit' ).val();
				let adrenoai_content_inputs_empty  = $( '.adrenoai_content_inputs_empty' ).val();
				$('.adrenoai_content_keyword_inputs_error').hide();
				
				$( ".adrenoai_content_content_box" ).empty();


				// If Keyword is empty
				if (keyword_value != '' && keyword_value != adrenoai_content_inputs_empty && keyword_value != ' ') {
					$( "#adrenoai_content_loading" ).show();
					$( '#adrenoai-regenerate-content-button' ).prop('disabled',true);
					var data = {
						'action'                   : 'adrenoai_auto_generate_content',
						'security'                 : adrenoai_security,
						'h1_tags_counts' 		   : h1_tags,
						'h2_tags_counts'           : h2_tags,
						'h3_tags_counts'           : h3_tags,
						'h4_tags_counts'           : h4_tags,
						'h5_tags_counts'           : h5_tags,
						'h6_tags_counts'           : h6_tags,
						'adrenoai_content_keyword' : keyword_value,
						'adrenoai_content_limits'  : words_limits,
					}
					$.ajax(
						{
							url: adrenoai_ajax_url,
							type: 'post',
							data: data,
							success: function(res){
								let response = $.trim( res );
								$( '#adrenoai-regenerate-content-button' ).prop('disabled',false);
								$( "#adrenoai_content_loading" ).hide();
								$( "#adrenoai-regenerate-content-button" ).val( 'Regenerate' );
								$( ".adrenoai_content_content_box" ).html( res );
							},
							error: function(xhr, status, error) {
								console.log( status );
								$( '#adrenoai-regenerate-content-button' ).prop('disabled',false);
								$( "#adrenoai_content_loading" ).hide();
								$( ".adrenoai_content_content_box" ).append( error );
							}
						}
					);

				} else {
					$('.adrenoai_content_keyword_inputs_error').show();
				}

			}
		);

		$('.adrenoai_content_keyword').on(
			'focus	',
				function(){
					$('.adrenoai_content_keyword_inputs_error').hide();
					$('.adrenoai_content_keyword_inputs_error').hide();
				}
		);

		// Copy Content from Text Area
		$( '.adrenoai-content-copy-icon' ).on(
			'click',
			function(){
				let adrenoai_content_copied  = $( '#adrenoai_content_text_copied' ).val();
				$( '.adrenoai_content_content_box' ).select();
				var text_area_content = $( '.adrenoai_content_content_box' ).text();

				if (text_area_content != '') {
					var $temp = $("<textarea>");
					$("body").append($temp);
					$temp.val(text_area_content).select();
					document.execCommand("copy");
					$temp.remove();
					$( "#adrenoai_copy_message" ).html( adrenoai_content_copied ).fadeIn( "slow" ).delay( 3000 ).fadeOut( "slow" );
				}
			}
		);
		//End User key Activation

		// User key Activation
		$( '#adrenoai_activation_submit' ).on(
			'click',
			function(e){
				e.preventDefault();

				let adreno_act_key = $( '.adrenoai_dashoard_form_text' ).val();
				let adreno_user_activated = $( '.adrenoai_dashoard_user_registered' ).val();
				let adreno_user_invalid = $( '.adrenoai_dashoard_user_invalid' ).val();
				let adreno_user_empty_key = $( '.adrenoai_dashoard_empty_key' ).val();
				$('.adrenoai_dashoard .notice' ).hide();

				if (adreno_act_key != '') {

					$( '.adrenoai_loading' ).show();
					$( '.adrenoai_activation_submit' ).prop( 'disabled', true );

					var data = {
						'action'                   : 'adrenoai_key_validation',
						'security'                 : adrenoai_security,
						'adrenoai_act_key'         : adreno_act_key,
					}

					$.ajax(
						{
							url: adrenoai_ajax_url,
							type: 'post',
							data: data,
							success: function(res){
								$( '.adrenoai_loading' ).hide();
								if (res == adreno_user_activated) {
									$( '.adrenoai_success' ).html(res);
									$( '.adrenoai_dashoard .notice-success' ).show();
									$( '#adrenoai_success' ).show();

									let adrenoai_user_activated = adrenoai_user_activation_check();

									if (adrenoai_user_activated.status == 'registered') {
										$( '.adrenoai_registration_form' ).hide();
										$( '#adrenoai_delete_activation_key' ).prop( 'disabled', false );
										$( '.adrenoai_dashoard_form_text' ).val( adrenoai_user_activated.user_key );
										$( '.adrenoai_dashoard_form_text_credit' ).html( adrenoai_user_activated.user_credits );
										$( '.adrenoai_dashoard_form_image_credit' ).html( adrenoai_user_activated.user_image_credits );
										$( '.adrenoai_unregistration_form' ).show();
									} else {
										$( '.adrenoai_registration_form' ).show();
										$( '.adrenoai_unregistration_form' ).hide();
										$( '.adrenoai_activation_submit' ).prop( 'disabled', false );
									}

								} else if (res == adreno_user_invalid) {
									$( '.adrenoai_activation_submit' ).prop( 'disabled', false );
									$( '.adrenoai_error' ).html( res );
									$( '.adrenoai_dashoard .notice-error' ).show();
									$( '#adrenoai_errors' ).show();
								}
							},
							error: function(xhr, status, error) {
								console.log( status );
								$( ".adrenoai_error" ).html( error );
							}
						}
					);
				} else {
					$( '.adrenoai_error' ).html(adreno_user_empty_key);
					$( '#adrenoai_errors' ).show();
				}

			}
		);
		//End User key Activation

		// Messages Closing on click
		$( '#adrenoai_errors .notice-dismiss' ).on(
			'click',
			function(event){
				event.preventDefault();
				$( '#adrenoai_errors' ).hide();
			}
		);
		$( '#adrenoai_success .notice-dismiss' ).on(
			'click',
			function(event){
				event.preventDefault();
				$( '#adrenoai_success' ).hide();
			}
		);
		// End Message Closing

		// User Key Deletion
		$( '#adrenoai_delete_activation_key' ).on(
			'click',
			function(e){
				e.preventDefault();

				let adreno_activated_key = $( '.adrenoai_activation_key' ).val();
				let adreno_activated_key_message = $( '#adrenoai_delete_activation_message' ).val();
				$( '#adrenoai_loading_unregister' ).show();
				$( '#adrenoai_delete_activation_key' ).prop( 'disabled', true );
				$( '.adrenoai_dashoard .notice' ).hide();

				var data = {
					'action'                   : 'adrenoai_delete_registered_key',
					'security'                 : adrenoai_security,
					'adrenoai_activated_key'   : adreno_activated_key,
				}

				$.ajax(
					{
						url: adrenoai_ajax_url,
						type: 'post',
						data: data,
						success: function(res){
							$( '#adrenoai_loading_unregister' ).hide();
							$( '.adrenoai_success' ).html(adreno_activated_key_message);
							$( '.adrenoai_dashoard .notice-success' ).show();
							$( '#adrenoai_success' ).show();
							$( '.adrenoai_activation_submit' ).prop( 'disabled', false );
							$( '.adrenoai_dashoard_form_text' ).val( '' );
							$( '.adrenoai_registration_form' ).show();
							$( '.adrenoai_unregistration_form' ).hide();
						},
						error: function(xhr, status, error) {
							console.log( status );
							$( ".adrenoai_error" ).html( error );
							$( '#adrenoai_errors' ).show();
						}
					}
				);

			}
		);
		// End User Key Deletion

		// User Text Credits Updation
		$( '.adrenoai_dashoard_text_update' ).on(
			'click',
			function(e){
				e.preventDefault();

				let adreno_activated_key = $( '.adrenoai_dashoard_form_text' ).val();
				$( '#adrenoai_loading_text_update' ).show();
				$( '.adrenoai_dashoard_form_text_credit' ).css( 'opacity', 0 );

				var data = {
					'action'                   : 'adrenoai_update_text_credits',
					'security'                 : adrenoai_security,
					'adrenoai_activated_key'   : adreno_activated_key,
				}

				$.ajax(
					{
						url: adrenoai_ajax_url,
						type: 'post',
						data: data,
						success: function(res){
							var response = $.parseJSON( res );
							$( '#adrenoai_loading_text_update' ).hide();
							if (response.status == 'available') {
								$( '.adrenoai_dashoard_form_text_credit' ).html(response.adreno_user_text_credits);
								$( '.adrenoai_dashoard_form_text_credit' ).css( 'opacity', 1 );
							} else if(response.status == 'unavailable') {
								$( '.adrenoai_dashoard_form_text_credit' ).html(response.adreno_user_text_credits);
								$( '.adrenoai_dashoard_form_text_credit' ).css( 'opacity', 1 );
							}
						},
						error: function(xhr, status, error) {
							console.log( status );
							$( ".adrenoai_error" ).html( error );
							$( '#adrenoai_errors' ).show();
						}
					}
				);
			}
		);
		// End User Text Update

		// User Image Credits Updation
		$( '.adrenoai_dashoard_image_update' ).on(
			'click',
			function(e){
				e.preventDefault();

				let adreno_activated_key = $( '.adrenoai_dashoard_form_text' ).val();
				$( '#adrenoai_loading_image_update' ).show();
				$( '.adrenoai_dashoard_form_image_credit' ).css( 'opacity', 0 );

				var data = {
					'action'                   : 'adrenoai_update_text_credits',
					'security'                 : adrenoai_security,
					'adrenoai_activated_key'   : adreno_activated_key,
				}

				$.ajax(
					{
						url: adrenoai_ajax_url,
						type: 'post',
						data: data,
						success: function(res){
							var response = $.parseJSON( res );
							$( '#adrenoai_loading_image_update' ).hide();
							if (response.status == 'available') {
								$( '.adrenoai_dashoard_form_image_credit' ).html('$' + response.adreno_user_image_credits );
								$( '.adrenoai_dashoard_form_image_credit' ).css( 'opacity', 1 );
							} else if(response.status == 'unavailable') {
								$( '.adrenoai_dashoard_form_image_credit' ).html('$' + response.adreno_user_image_credits);
								$( '.adrenoai_dashoard_form_image_credit' ).css( 'opacity', 1 );
							}
						},
						error: function(xhr, status, error) {
							console.log( status );
							$( ".adrenoai_error" ).html( error );
							$( '#adrenoai_errors' ).show();
						}
					}
				);
			}
		);
		// End User Image Update

		// About Page Submission
		$('#adreno_about_page').on(
			'click',
			function(e){
				e.preventDefault();
				let organization_name 		 = $('#adrenoai_about_organization_name').val();
				let industry_name 	  		 = $('#adrenoai_about_industry_name').val();
				let product			  		 = $('#adrenoai_about_product').val();
				let related_keywords  		 = $('#adrenoai_about_related_keywords').val();
				let unregister_user_message  = $('#adreno_unregister_user').val();
				let keyword_limit_message  = $('.adrenoai_about_keyword_limit_message').val();
				$( '.adrenoai-dashoard-about-form .notice' ).hide();
				
				if(adrenoai_user_activated.status == 'registered'){

					if(organization_name != '' && industry_name != '' && product !='' && related_keywords != ''){

						var keyword_values = $('#adrenoai_about_related_keywords').val().split(',');
						if(keyword_values.length > 8){

							var data = {
								'action'                   : 'adrenoai_update_about_info',
								'security'                 : adrenoai_security,
								'adreno_organization_name' : organization_name,
								'adreno_industry_name'     : industry_name,
								'adreno_product'           : product,
								'adreno_related_keywords'  : related_keywords
							}

							$.ajax(
								{
									url: adrenoai_ajax_url,
									type: 'post',
									data: data,
									success: function(res){
										var response_about_page = $.parseJSON( res );
										$( '.adrenoai-dashoard-about-form .notice' ).hide();
										$('#adrenoai_success').show();
										$('#adrenoai_about_organization_name').val(response_about_page.organization_name);
										$('#adrenoai_about_industry_name').val(response_about_page.industry_name);
										$('#adrenoai_about_product').html(response_about_page.industry_name);
										$('#adrenoai_about_related_keywords').html(response_about_page.industry_name);
									},
									error: function(xhr, status, error) {
										console.log( status );
										$( ".adrenoai_error" ).html( error );
										$( '#adrenoai_errors' ).show();
									}
								}
							);

						} else {
							$( ".adrenoai_about_error" ).html( keyword_limit_message );
							$( '#adrenoai_errors' ).show();
						}

					} else {
						$('#adrenoai_errors').show();
					}
				} else {
					$( ".adrenoai_about_error" ).html( unregister_user_message );
					$( '#adrenoai_errors' ).show();
				}
			}
		);
		// End About Page Working


		// About Page Reset  
		$('.adreno_about_page_reset').on(
			'click',
			function(e){
				e.preventDefault();
				$('#adrenoai_about_organization_name').val('');
				$('#adrenoai_about_industry_name').val('');
				$('#adrenoai_about_product').val('');
				$('#adrenoai_about_related_keywords').val('');
			}
		);
		
		// Suggestion Function of Content Generation
		$('#adrenoai_content_inputs').on(
			'click',
			function(e){
				e.preventDefault();
				$('.adrenoai_content_keyword_inputs_error').hide();
				$('#adrenoai_loading_suggestion_keywords').show();
				$('#adrenoai_content_keyword').val('');
				$('#adrenoai_content_inputs').prop('disabled', true);
				var data = {
					'action'   : 'adrenoai_suggest_keywords',
					'security' : adrenoai_security,
				}

				$.ajax(
					{
						url: adrenoai_ajax_url,
						type: 'post',
						data: data,
						success: function(res){
							$('#adrenoai_loading_suggestion_keywords').hide();
							$('.adrenoai_content_keyword_inputs_error').html(res);
							$('.adrenoai_content_keyword_inputs_error').show();
							$('#adrenoai_content_inputs').prop('disabled', false);
						},
						error: function(xhr, status, error) {
							console.log( status );
							$('#adrenoai_content_inputs').prop('disabled', false);
							$( ".adrenoai_content_content_box" ).append( error );
						}
					}
				);
			}
		);

		// Image Generation

			$('.adrenoai-image-generation-custom-name').hide();
			$('.adrenoai_image_title_alt_radio_buttons').hide();
			$('.adrenoai_auto_title').hide();
			$('.adrenoai_auto_alt').hide();

			let adrenoai_image_url = $('.adrenoai-generateed-image #adrenoai_auto_generated_image').attr("src");
			if(adrenoai_image_url == ''){
				$('.adrenoai_image_saving_options').hide();
			} else {
				$('.adrenoai_image_saving_options').show();
			}

			$('.adrenoai-regenerate-image-button').on(
				'click',
				function (e) {
				e.preventDefault();
				let adrenoai_image_input_keyword = $('#adrenoai_image_input_keyword').val();
				let adrenoai_image_size = $('input[name="adrenoai-image-size"]:checked').val();
				let adrenoai_empty_act_key = $('#adrenoai_empty_act_key').val();
				$('.adrenoai-add-image-buttons_success').html('');
					if(adrenoai_image_input_keyword != '' & adrenoai_image_input_keyword != ' '){

						$('.adrenoai-generateed-image #adrenoai_auto_generated_image').attr("src", " ");
						$('#adrenoai_loading_image_suggestion_div').show();
						$('.adrenoai-regenerate-image-button').prop('disabled', true);

						var data = {
							'action'   : 'adrenoai_image_generation',
							'security' : adrenoai_security,
							'keywords' : adrenoai_image_input_keyword,
							'size' : adrenoai_image_size,
						}

						$.ajax(
							{
								url: adrenoai_ajax_url,
								type: 'post',
								data: data,
								success: function(res){
									// alert(res);
									var image_generation_response = $.parseJSON(res);
									$('#adrenoai_loading_image_suggestion_div').hide();
									$('.adrenoai-regenerate-image-button').prop('disabled', false);
									if(image_generation_response.status == 'success'){
										$('.adrenoai-regenerate-image-button').val('Regenerate');
										$('.adrenoai_image_saving_options').show();
										$('.adrenoai-image-generation-radio-buttons').show();
										$('.adrenoai-generateed-image #adrenoai_auto_generated_image').attr("src", image_generation_response.image_url);
									} else if (image_generation_response.status == 'error'){
										alert(res);
										$('.adrenoai-add-image-buttons_error').html(adrenoai_empty_act_key);
									}
								},
								error: function(xhr, status, error) {
									console.log( status );
									$('.adrenoai-regenerate-image-button').prop('disabled', false);
									$('.adrenoai-generateed-image p').html(error);
								}
							}
						);

					}else {
						$('.adrenoai-image-form-error-message').show();
					}
				}
			);

			$('#adrenoai_image_input_keyword').on(
				'focus',
					function(){
						$('#adrenoai-image-form-error-message').hide();
						$('#adrenoai-image-form-error-message').html('');
					}
			);
			
			$('.adrenoai_image_copy_keywords').on(
				'click',
				function(e) {
					e.preventDefault();
					let adrenoai_content_keyword = $('.adrenoai_content_keyword').val();
					let adrenoai_conten_keyword_empty = $('#adrenoai_conten_keyword_empty').val();
					if(adrenoai_content_keyword != ''){
						$('#adrenoai_image_input_keyword').val(adrenoai_content_keyword);
					}else{
						$('#adrenoai-image-form-error-message').html(adrenoai_conten_keyword_empty);
						$('#adrenoai-image-form-error-message').show();
					}
				}
			);
			// Suggestion Function in Image Generation
			$('.adrenoai_image_keyword_suggest').on(
				'click',
				function(e){
					e.preventDefault();
					$('#adrenoai-image-form-error-message').hide();
					$('#adrenoai_loading_image_suggestion_keywords').show();
					$('#adrenoai_image_input_keyword').val('');
					$('.adrenoai-add-image-buttons_success').html('');
					$('.adrenoai_image_keyword_suggest').prop('disabled', true);
					var data = {
						'action'   : 'adrenoai_suggest_keywords',
						'security' : adrenoai_security,
					}

					$.ajax(
						{
							url: adrenoai_ajax_url,
							type: 'post',
							data: data,
							success: function(res){
								$('.adrenoai_image_keyword_suggest').prop('disabled', false);
								$('#adrenoai_loading_image_suggestion_keywords').hide();
								$('#adrenoai-image-form-error-message').html(res);
								$('#adrenoai-image-form-error-message').show();
							},
							error: function(xhr, status, error) {
								console.log( status );
								$('.adrenoai_image_keyword_suggest').prop('disabled', false);
								$( "#adrenoai_image_input_keyword" ).val( error );
							}
						}
					);
				}
			);
			// End Suggestion
			
			// Add to Featured Image
			$('.adrenoai_add_featured_image').on(
				'click',
				function(e){
					e.preventDefault();
					let adrenoai_image_url = $('.adrenoai-generateed-image #adrenoai_auto_generated_image').attr("src");
					let adrenoai_current_page_id = $('#adrenoai_current_page_id').val();
					$('.adrenoai_image_empty_image').hide();
					$('.adrenoai_image_featured_image_set').hide();
				
					if( adrenoai_image_url != '' && adrenoai_current_page_id != ''){

						let adrenoai_image_title = $('input[name="adrenoai_image_title"]:checked').val();
						let adreno_image_alt = $("input[name='adrenoai_image_alt_title']:checked").val();
						let adrenoai_image_title_value;
						let adrenoai_image_alt_value;

						if(adrenoai_image_title == 'custom'){
							adrenoai_image_title_value = $('#adrenoai_image_custom_title').val();
						} else if (adrenoai_image_title == 'auto') {
							adrenoai_image_title_value = $('#adrenoai_auto_title_input').val();
						}

						if(adreno_image_alt == 'custom'){
							adrenoai_image_alt_value = $('#adrenoai_image_custom_alt').val();
						} else if (adreno_image_alt == 'auto') {
							adrenoai_image_alt_value = $('#adrenoai_auto_alt_input').val();		
						}

						$('#adrenoai_loading_image_saving_loading').show();
						$('#adrenoai_loading_image_added').show();
						$('.adrenoai_add_featured_image').prop('disabled',true);
						$('.adrenoai_image_saving_options').hide();
						
						var data = {
							'action'   : 'adrenoai_add_featured_image',
							'security' : adrenoai_security,
							'adrenoai_image_url': adrenoai_image_url,
							'adrenoai_current_page_id' : adrenoai_current_page_id,
							'adrenoai_image_alt' : adrenoai_image_alt_value,
							'adrenoai_image_title' : adrenoai_image_title_value,
						}

						$.ajax(
							{
								url: adrenoai_ajax_url,
								type: 'post',
								data: data,
								success: function(res){
									$('.adrenoai-add-image-buttons_success').html(res);
									$('#adrenoai_loading_image_saving_loading').hide();
									$('#adrenoai_loading_image_added').hide();
									$('.adrenoai-image-generation-radio-buttons').hide();
									$('#adrenoai_image_input_keyword').val('');
									$('.adrenoai_image_saving_options').hide();
								},
								error: function(xhr, status, error) {
									console.log( status );

								}
							}
						);

					} else {
						$('.adrenoai_image_empty_image').show();
					}
			});

			// Image Saving Radio Buttons


			$('#adrenoai_image_saving_select_options').change(
				function(){
					var selected_image_saving_option = $('#adrenoai_image_saving_select_options').val();
					if( selected_image_saving_option == 'featured_image' ){
						$('.adrenoai-add-image-buttons').show();
						$('.adrenoai_image_title_alt_radio_buttons').show();
						$('.adrenoai-image-generation-radio').hide();
						$('.adrenoai-image-form-error-message').hide();
					} else if( selected_image_saving_option == 'media_library' ) {
						$('.adrenoai-add-image-buttons').hide();
						$('.adrenoai_image_title_alt_radio_buttons').show();
						$('.adrenoai-image-generation-radio').show();
						$('.adrenoai-image-form-error-message').hide();
					} else {
						$('.adrenoai-add-image-buttons').hide();
						$('.adrenoai_image_title_alt_radio_buttons').hide();
						$('.adrenoai-image-generation-radio').hide();
						$('.adrenoai-image-form-error-message').hide();
					}

				}
			);

			// Image Radio buttons for alt and title
			$('#adrenoai_image_title').on(
				'click',
				function(){
					$('#adrenoai_image_generation_alt').show();
					$('.adrenoai_auto_title').hide();
			});
			$('#adrenoai_image_title_auto').on(
				'click',
				function(){
					$('#adrenoai_image_generation_alt').hide();
					$('.adrenoai_auto_title').show();
			});

			$('#adrenoai_image_alt_title').on(
				'click',
				function(){
					$('#adrenoai_image_generation_title').show();
					$('.adrenoai_auto_alt').hide();
			});
			$('#adrenoai_image_alt_title_auto').on(
				'click',
				function(){
					$('#adrenoai_image_generation_title').hide();
					$('.adrenoai_auto_alt').show();
			});

			$('.adrenoai_auto_title_confirmation').on(
				'click',
				function(e){
					e.preventDefault();
					let adrenoai_image_url = $('.adrenoai-generateed-image #adrenoai_auto_generated_image').attr("src");
					$('.adrenoai_image_empty_image').hide();
					$('#adrenoai_auto_title_input').val('');

					if(adrenoai_image_url != ''){

						$('#adrenoai_loading_image_auto_title').show();
						$('.adrenoai_auto_title_confirmation').hide();

						var data = {
							'action'   : 'adrenoai_create_auto_title',
							'security' : adrenoai_security,
							'adrenoai_image_url': adrenoai_image_url,
						}

						$.ajax(
							{
								url: adrenoai_ajax_url,
								type: 'post',
								data: data,
								success: function(res){
									$('#adrenoai_loading_image_auto_title').hide();
									$('#adrenoai_auto_title_input').val(res);
								},
								error: function(xhr, status, error) {
									console.log( status );
								}
							}
						);
					} else {
						$('.adrenoai_image_empty_image').show();
					}

				}
			);


			$('.adrenoai_auto_alt_confirmation').on(
				'click',
				function(e){
					e.preventDefault();
					let adrenoai_image_url = $('.adrenoai-generateed-image #adrenoai_auto_generated_image').attr("src");
					$('.adrenoai_image_empty_image').hide();
					$('#adrenoai_auto_alt_input').val('');

					if(adrenoai_image_url != ''){

						$('#adrenoai_loading_image_auto_alt').show();
						$('.adrenoai_auto_alt_confirmation').hide();

						var data = {
							'action'   : 'adrenoai_create_auto_alt',
							'security' : adrenoai_security,
							'adrenoai_image_url': adrenoai_image_url,
						}

						$.ajax(
							{
								url: adrenoai_ajax_url,
								type: 'post',
								data: data,
								success: function(res){
									$('#adrenoai_loading_image_auto_alt').hide();
									$('#adrenoai_auto_alt_input').val(res);
								},
								error: function(xhr, status, error) {
									console.log( status );
								}
							}
						);
					} else {
						$('.adrenoai_image_empty_image').show();
					}

				}
			);



			$('.adrenoai_image_adding_in_library').on(
				'click',
				function(e){
					e.preventDefault();
					let adrenoai_image_url = $('.adrenoai-generateed-image #adrenoai_auto_generated_image').attr("src");
					$('.adrenoai_image_empty_image').hide();
					
					if(adrenoai_image_url != ''){
						
						let adrenoai_image_title = $('input[name="adrenoai_image_title"]:checked').val();
						let adreno_image_alt = $("input[name='adrenoai_image_alt_title']:checked").val();
						let adrenoai_image_title_value;
						let adrenoai_image_alt_value;
						$('#adrenoai_image_saving_select_options').hide();
						$('.adrenoai_image_title_alt_radio_buttons').hide();
						$('.adrenoai-image-generation-radio').hide();
						$('#adrenoai_loading_image_saving_loading').show();
						$('#adrenoai_loading_image_added').show();

						if(adrenoai_image_title == 'custom'){
							adrenoai_image_title_value = $('#adrenoai_image_custom_title').val();
						} else if (adrenoai_image_title == 'auto') {
							adrenoai_image_title_value = $('#adrenoai_auto_title_input').val();
						}

						if(adreno_image_alt == 'custom'){
							adrenoai_image_alt_value = $('#adrenoai_image_custom_alt').val();
						} else if (adreno_image_alt == 'auto') {
							adrenoai_image_alt_value = $('#adrenoai_auto_alt_input').val();		
						}


						var data = {
							'action'   : 'adrenoai_add_image_to_media_library',
							'security' : adrenoai_security,
							'adrenoai_image_url': adrenoai_image_url,
							'adrenoai_image_alt' : adrenoai_image_alt_value,
							'adrenoai_image_title' : adrenoai_image_title_value,
						}

						$.ajax(
							{
								url: adrenoai_ajax_url,
								type: 'post',
								data: data,
								success: function(res){

									var response = $.parseJSON( res );
									$('#adrenoai_loading_image_saving_loading').hide();
									$('#adrenoai_loading_image_added').hide();
									if(response.status == 'success'){
										$('.adrenoai-add-image-buttons_success').html(response.success_message);
										$('#adrenoai_image_input_keyword').val('');
										$('.adrenoai-generateed-image #adrenoai_auto_generated_image').attr("src", " ");
										adrenoai_image_alt_value = "";
										adrenoai_image_title_value = "";
										$('.adrenoai_image_saving_options').hide();
									} else if(response.status == 'error') {
										$('.adrenoai-add-image-buttons_error').html(response.error_message);
									}
								},
								error: function(xhr, status, error) {
									console.log( status );
								}
							}
						);



					} else {
						$('.adrenoai_image_empty_image').show();
					}

				}	
			);
		// End Image Generation Form
	}
);
