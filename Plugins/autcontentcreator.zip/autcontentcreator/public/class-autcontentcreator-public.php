<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       https://autcontentcreator
 * @since      1.0.0
 *
 * @package    Autcontentcreator
 * @subpackage Autcontentcreator/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Autcontentcreator
 * @subpackage Autcontentcreator/public
 * @author     Sigma Square <info@sigmasquare.com>
 */
/**
 * Using Orhanerday Open AI
 */
 use Orhanerday\OpenAi\OpenAi;

class Autcontentcreator_Public
{
    /**
     * The ID of this plugin.
     *
     * @since    1.0.0
     *
     * @var string the ID of this plugin
     */
    private $plugin_name;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
     *
     * @param string $plugin_name the name of the plugin
     * @param string $version     the version of this plugin
     */
    public function __construct($plugin_name, $version)
    {
        $this->plugin_name = $plugin_name;
        $this->version = $version;
        require(__DIR__ . '/../vendor/autoload.php');
    }

    /**
     * Register the stylesheets for the public-facing side of the site.
     *
     * @since    1.0.0
     */
    public function enqueue_styles()
    {
        /*
         * This function is provided for demonstration purposes only.
         *
         * An instance of this class should be passed to the run() function
         * defined in Autcontentcreator_Loader as all of the hooks are defined
         * in that particular class.
         *
         * The Autcontentcreator_Loader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.
         */

        wp_enqueue_style($this->plugin_name, plugin_dir_url(__FILE__).'css/autcontentcreator-public.css', [], $this->version, 'all');
    }

    /**
     * Register the JavaScript for the public-facing side of the site.
     *
     * @since    1.0.0
     */
    public function enqueue_scripts()
    {
        /*
         * This function is provided for demonstration purposes only.
         *
         * An instance of this class should be passed to the run() function
         * defined in Autcontentcreator_Loader as all of the hooks are defined
         * in that particular class.
         *
         * The Autcontentcreator_Loader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.
         */

        wp_enqueue_script($this->plugin_name, plugin_dir_url(__FILE__).'js/autcontentcreator-public.js', ['jquery'], $this->version, false);
    }

    public function register_custom_endpoint()
    {
        /*
         * This function will register path and a call back function
         * for communicating with other hosts.
		 * 
         */

        // Generating Content
        register_rest_route('auto-content-generator/v1', '/send-inputs', [
            'methods' => 'POST',
            'callback' => [$this, 'get_values_for_content_generation'],
        ]);

        // User Key Validation
        register_rest_route('auto-content-generator/v1', '/key_validation', [
            'methods' => 'POST',
            'callback' => [$this, 'activation_key_validation'],
        ]);
    }

    public function get_values_for_content_generation($data)
    {
        // Getting Values from request
        $subject_value             = $data->get_param('subject');
        $keyword_value             = $data->get_param('keyword');
        $registered_activation_key = $data->get_param('key');

        // Credits Decrement
        $get_user_with_key = new WP_User_Query( array( 'meta_key' => 'activation_key', 'meta_value' => $registered_activation_key ) );
        $users = $get_user_with_key->get_results();
        if (!empty($users)) {
            foreach ($users as $user){
                $user_credit = get_user_meta($user->ID, 'user_credits', TRUE);
                if($user_credit > 0){
                    $user_balance_credit = $user_credit - 1;
                    update_user_meta( $user->ID, 'user_credits', $user_balance_credit );
                }
            } 
        }

        if($user_credit > 0){    

            // Api Communication
            $open_ai_key = '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';
            $open_ai = new OpenAi( $open_ai_key );
            $prompt = $subject_value.' + '.$keyword_value;

            $complete = $open_ai->completion([
                'model' => 'text-davinci-003',
                'prompt' => $prompt,
                'temperature' => 0.7,
                'max_tokens' => 256, 
                'stop' => '\n'
            ]);

            $complete_text = json_decode($complete);
            $response = $complete_text->choices[0]->text;

        } else {
            $response = 'Your free trial credits are expired. Please Visit our site and purchase plan';
        }

        return $response;
    }

    public function activation_key_validation($data){

        $key_value = $data->get_param('key');

        // Getting User with getting key
        $user_query = new WP_User_Query( array( 'meta_key' => 'activation_key', 'meta_value' => $key_value ) );
        $users = $user_query->get_results();    

        if(!empty($users)){
            return 1;
        }else{
            return 0;
        }
    }
}