<?php

session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "student";

//Create Connection
$conn = new mysqli($servername, $username, $password, $dbname);
if($conn->connect_error){
    die("Connection Failed: " . $conn->connect_error);
} 

$email = $_REQUEST['email_id'];
$pass = $_REQUEST['pass_id'];


$duplicate=mysqli_query($conn,"SELECT * from stdentDb where  email='$email' AND pass='$pass'");
if (mysqli_num_rows($duplicate)==TRUE){

    while($row = $duplicate->fetch_assoc()){
        $_SESSION['name'] = $row['st_name'];
        $_SESSION['email_id'] = $email;
       echo 1;
    }
} else {
    echo 0;
}


// $newUser = $_SESSION['email_id'];
// if(isset($newUser)){
    // header('location:welcome.php');
// }


$conn->close();
?>