
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Image Upload Using Ajax</title>
    <style>
        #error_message{
            color: red;
            font-weight: bold;
        }
        .gallery img{
            margin-top: 50px;
            width: 600px;
            height: 400px;
        }
    </style>
</head>
<body>
    <p id="error_message"></p>
    <form action="upload.php" id="form" method="post" enctype="multipart/form-data">
        <input type="file" id="myImage">
        <input type="submit" id="submit" value="upload">
    </form>
    <div class="gallery">
        <img src="uploads/default-image.jpg" id="uploadedImg">
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <script>
        $(document).ready(function(){

        $("#submit").click(function(e){
            e.preventDefault();
            let form_data = new FormData();
            let img = $("#myImage")[0].files;

            if(img.length > 0){
                form_data.append('my_image',img[0]);
                $.ajax({
                    url:            'upload.php',
                    type:           'post',
                    data:    form_data,
                    contentType:    false,
                    processData:    false,
                    success: function(res){
                        const data = JSON.parse(res);
                        
                        if(data.error !=1){
                            let path = "uploads/"+data.src;
                            $("#uploadedImg").attr("src", path);
                        } else {
                            $("#error_message").text(data.error);
                        }
                        
                    }
                });


            } else {
                $("#error_message").text("Please Select an Image")
            }
        });

        }); 
    </script>
</body>
</html>