<?php



$servername = "localhost";
$username = "root";
$password = "";
$dbname = "image_Upload";

$conn = new mysqli($servername, $username, $password, $dbname);

// Create Database
$sql = "CREATE DATABASE IF NOT EXISTS image_Upload";
if($conn->query($sql)== TRUE){
    // echo "Database Created Successfully<br>";
}else {
    echo "Error Creating Database".$conn->error;
}
//Create Connection
if($conn->connect_error){
    die("Connection Failed: " . $conn->connect_error);
}


$sql = "CREATE TABLE IF NOT EXISTS image_names (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    img_name VARCHAR(255) NOT NULL,
    reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";
        
if ($conn->query($sql) === TRUE) {
    //   echo "Table MyGuests created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}
        
// $conn->close();