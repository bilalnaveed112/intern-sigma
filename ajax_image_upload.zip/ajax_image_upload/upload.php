<?php

include 'db_conn.php';

if (isset($_FILES['my_image'])){
    
    $img_name = $_FILES['my_image']['name'];
    $img_size = $_FILES['my_image']['size'];
    $tmp_name = $_FILES['my_image']['tmp_name'];
    $error    = $_FILES['my_image']['error'];

    if ($error === 0){
    
            $img_ex = pathinfo($img_name, PATHINFO_EXTENSION);
            $new_img_name = uniqid("IMG-",true).'.'.$img_ex;
            $img_upload_path = 'uploads/'.$new_img_name;

            move_uploaded_file($tmp_name, $img_upload_path);

            $sql = "INSERT INTO image_names(img_name) Values ('$new_img_name')";
            mysqli_query($conn, $sql);

            $res = array('error' => '0', 'src' => $new_img_name);
            echo json_encode($res);
            exit();
            
    } else {
        $error = "Unknown Error Occured!";
        echo json_encode($error);
        exit();
    }

}