

<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>HTML TO WORDPRESS</title>

<?php get_header(); ?>

<!-- Home Video Slider start -->
    <?php  
      $label_query = array(
        'post_type'=> 'label',
        'posts_per_page' => -1,
        'order' => 'ASC'

      );
      $labels = get_posts($label_query);
      ?>

<div class="container-fluid home-hero-video-section">
  <iframe src="https://player.vimeo.com/video/171139017?background=1&amp;autoplay=1&amp;loop=1&amp;byline=0&amp;title=0" width="640" height="360" frameborder="0" allow="autoplay; fullscreen" allowfullscreen="allowfullscreen">
  </iframe>
  <div class="container">
    <div class="row">
      <div class="col">
        <div id="home-inner-slider" class="carousel slide" data-ride="carousel">
          <!-- The slideshow -->
          <div class="carousel-inner">
          <?php
          $i = 0;
          foreach($labels as $label){       
          ?>
                <div class="carousel-item <?php if($i == 0)  echo 'active';  ?>">
                  <div class="slider-caption">
                    <h1> <small><?php echo $label->post_content; ?></small> <?php echo $label->post_title; ?></h1>
              </div>
            </div>
          <?php 
            $i++;
          }
          ?>     
          </div>
          <!-- Left and right controls -->
          <a class="carousel-control-prev" href="#home-inner-slider" data-slide="prev"><i class="fas fa-chevron-left"></i></a> <a class="carousel-control-next" href="#home-inner-slider" data-slide="next"><i class="fas fa-chevron-right"></i></a> </div>
        <div class="text-center"> <a class="theme-button" href="#">View projects</a> </div>
      </div>
    </div>
  </div>
</div>
<!-- Home Video Slider end -->

<!-- Filter section start -->
<div class="container filter-section">
  <div class="row">
    <div class="col">
      <div class="filter-box">
        <div class="row">
          <div class="col-sm-12 col-lg-6">
            <div class="search-box"> <i class="fas fa-search-location"></i>
              <input placeholder="Enter an address, town, street, zip or property ID" type="text" name="" value="">
            </div>
          </div>
          <div class="col-6 col-lg-3">
            <div class="theme-dropdown">
              <select class="form-control">
                <option>All Cities</option>
                <option> Orihuela Costa</option>
                <option> Torrevieja</option>
              </select>
            </div>
          </div>
          <div class="col-6 col-lg-3">
            <div class="theme-dropdown">
              <select class="form-control">
                <option>All Areas</option>
                <option> Cabo Roig</option>
                <option> Campoamor</option>
                <option> La Zenia</option>
                <option> Los Dolses</option>
                <option> Punta Prima</option>
                <option>Villamartin
                <option>
              </select>
            </div>
          </div>
          <div class="col-lg-12">
            <div class="both-button-group">
              <button class="all-filter-show-button" type="button" name="button"><i class="fas fa-chevron-down"></i> Advanced</button>
              <button class="theme-button" type="button" name="button"><i class="fas fa-search"></i> Search</button>
            </div>
          </div>
          <div class="col-lg-12" id="all-filter-box">
            <div class="row">
              <div class="col-6 col-lg-3">
                <div class="theme-dropdown">
                  <select  class="form-control">
                    <option value="">All Status</option>
                    <option value="rental"> Rentals</option>
                    <option value="sales"> Sales</option>
                  </select>
                </div>
              </div>
              <div class="col-6 col-lg-3">
                <div class="theme-dropdown">
                  <select  class="form-control">
                    <option>All Types</option>
                    <option> Apartment</option>
                    <option> Detached villa</option>
                    <option> Detached villa</option>
                    <option> Ground floor apartment</option>
                    <option> Penthouse</option>
                    <option> Townhouse</option>
                  </select>
                </div>
              </div>
              <div class="col-6 col-lg-3">
                <div class="theme-dropdown">
                  <select  class="form-control">
                    <option value="">All Labels</option>
                    <option value="nowa-en"> Just added</option>
                    <option value="luks-2"> Luxury</option>
                    <option value="polecana-en"> Recomended</option>
                    <option value="obnizka-en"> Reduced</option>
                    <option value="sold"> Sold</option>
                  </select>
                </div>
              </div>
              <div class="col-6 col-lg-3">
                <input placeholder="Property ID" class="form-control" type="text" name="" value="">
              </div>
              <div class="col-6 col-lg-3">
                <div class="theme-dropdown">
                  <select  class="form-control">
                    <option value="">Beds</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                    <option value="6">6</option>
                    <option value="7">7</option>
                    <option value="8">8</option>
                    <option value="9">9</option>
                    <option value="10">10</option>
                    <option value="any">Any</option>
                  </select>
                </div>
              </div>
              <div class="col-6 col-lg-3">
                <div class="theme-dropdown">
                  <select  class="form-control">
                    <option value="">Baths</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                    <option value="6">6</option>
                    <option value="7">7</option>
                    <option value="8">8</option>
                    <option value="9">9</option>
                    <option value="10">10</option>
                    <option value="any">Any</option>
                  </select>
                </div>
              </div>
              <div class="col-6 col-lg-3">
                <div class="theme-dropdown">
                  <select  class="form-control">
                    <option value="">Min Price</option>
                    <option value="any">Any</option>
                    <option value="1000">1.000€</option>
                    <option value="5000">5.000€</option>
                    <option value="10000">10.000€</option>
                    <option value="50000">50.000€</option>
                    <option value="100000">100.000€</option>
                    <option value="200000">200.000€</option>
                    <option value="300000">300.000€</option>
                    <option value="400000">400.000€</option>
                    <option value="500000">500.000€</option>
                    <option value="600000">600.000€</option>
                    <option value="700000">700.000€</option>
                    <option value="800000">800.000€</option>
                    <option value="900000">900.000€</option>
                    <option value="1000000">1.000.000€</option>
                    <option value="1500000">1.500.000€</option>
                    <option value="2000000">2.000.000€</option>
                    <option value="2500000">2.500.000€</option>
                    <option value="5000000">5.000.000€</option>
                  </select>
                </div>
              </div>
              <div class="col-6 col-lg-3">
                <div class="theme-dropdown">
                  <select  class="form-control">
                    <option value="">Max Price</option>
                    <option value="any">Any</option>
                    <option value="5000">5.000€</option>
                    <option value="10000">10.000€</option>
                    <option value="50000">50.000€</option>
                    <option value="100000">100.000€</option>
                    <option value="200000">200.000€</option>
                    <option value="300000">300.000€</option>
                    <option value="400000">400.000€</option>
                    <option value="500000">500.000€</option>
                    <option value="600000">600.000€</option>
                    <option value="700000">700.000€</option>
                    <option value="800000">800.000€</option>
                    <option value="900000">900.000€</option>
                    <option value="1000000">1.000.000€</option>
                    <option value="1500000">1.500.000€</option>
                    <option value="2000000">2.000.000€</option>
                    <option value="2500000">2.500.000€</option>
                    <option value="5000000">5.000.000€</option>
                    <option value="10000000">10.000.000€</option>
                  </select>
                </div>
              </div>
              <div class="col-6 col-lg-6">
                <input placeholder="Min Area (m²)" class="form-control" type="text" name="" value="">
              </div>
              <div class="col-6 col-lg-6">
                <input placeholder="Max Area (m²)" class="form-control" type="text" name="" value="">
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Filter section end -->

<!-- Single Post   -->

<div class="container">
  <div class="row">
  <?php
        $args = array(
        'post_type' => 'post',
        'category_name' => 'sample'
        ); 
        $q = new WP_Query($args);
        if ( $q->have_posts() ) { 
        while ( $q->have_posts() ) {
        $q->the_post();
        $image_path = wp_get_attachment_image_src(
        get_post_thumbnail_id(),'large');
  ?>
    <div class="col-lg-12">
      <div class="company-intro-section">
        <div class="intro-caption">
            <h2 class="theme-title"><?php the_title(); ?> <i> <img src="<?php echo get_template_directory_uri(); ?>/images/logo-icon.png" alt=""> </i> </h2>
            <p><?php the_content(); ?></p>
            <div class="text-center"> <a class="theme-button" href="#">About us</a> </div>
        </div>
        <div class="intro-bg" style="background:url(<?php echo $image_path[0] ?>)"></div>
      </div>
    </div>
    <?php }} ?>
  </div>
</div>

<!-- Single Post end   -->

<!-- Product items start -->
<div class="container">
  <div class="row">
    <div class="col-lg-12">
      <h2 class="theme-title">PROPERTIES IN CABO ROIG & CAMPOAMOR <i> <img src="<?php echo get_template_directory_uri(); ?>/images/logo-icon.png" alt=""> </i> </h2>
    </div>

    <?php
            $wp_new = array(
              'post_type' => 'cabo',
              'post_status' => 'publish'
            );
            $cabo_query = new wp_query($wp_new);
            while($cabo_query->have_posts()){
              $cabo_query->the_post();
              $image_path = wp_get_attachment_image_src(
                get_post_thumbnail_id(),'large'
              );
          ?>
    <div class="col-sm-6 col-lg-4">
      <div class="product-card-box">
        <div class="product-card-item-img" style="background:url(<?php echo $image_path[0] ?>">
          <div class="product-item-pil-tool">
            <ul>
              <li><?php echo get_post_meta($post->ID, 'size', true)?></li>
              <li><?php echo get_post_meta($post->ID, 'price', true)?></li>
            </ul>
          </div>
        </div>
        <div class="product-card-content-box">
          <h3> <a href="#"><?php the_title(); ?></a> </h3>
          <p><?php the_excerpt() ?> </p>
          <a class="theme-button" href="#">SEE DETAIL</a> </div>
      </div>
    </div>
    <?php } ?>
    
    <div class="col-lg-12 text-center"> <a class="theme-button" href="#">LOAD MORE</a> </div>
    <!-- Product items End -->

    <!-- Product items carousel start -->
    
    <?php
    $prop_cat = get_terms([
      'taxonomy' => 'property_category',
      'hide_empty' => 'false',
      'orderby' => 'name',
      'order' => 'DESC'
    ]);

    foreach($prop_cat as $prop_data){
    ?>
    <div class="col-lg-12">
      <h2 class="theme-title"><?php echo $prop_data->name; ?><i> <img src="<?php echo get_template_directory_uri(); ?>/images/logo-icon.png" alt=""> </i> </h2>
    </div>
  
    <div class="col-lg-12">
      <div class="owl-carousel custom-carousel">
      <?php
            $wp_new = array(
              'post_type' => 'property',
              'post_status' => 'publish',
              'tax_query' => array(
                array(

                  'taxonomy' => 'property_category',
                  'field' => 'term_id',
                  'terms' =>  $prop_data->term_id
                  )
              )
            );
            $prop_query = new wp_query($wp_new);
            while($prop_query->have_posts()){
              $prop_query->the_post();
              $image_path = wp_get_attachment_image_src(
                get_post_thumbnail_id(),'large'
              );
          ?>
        <div class="item">
        <div class="product-card-box">
            <div class="product-card-item-img" style="background:url(<?php echo $image_path[0] ?>"> </div>
            <div class="product-card-content-box">
              <h3> <a href="#"><?php the_title();  ?></a> </h3>
              <p><?php the_content();  ?></p>
              <a class="theme-button" href="#">SEE DETAIL</a> </div>
          </div>
        </div>
        <?php
          }
        ?>
      </div>
    </div> 
    <?php  } ?>
        
<!-- Product items carousel start -->

<!-- Home Video Slider start -->
<div class="container-fluid home-hero-video-section video-modal-container">
  <iframe src="https://player.vimeo.com/video/171139017?background=1&amp;autoplay=1&amp;loop=1&amp;byline=0&amp;title=0" width="640" height="360" frameborder="0" allow="autoplay; fullscreen" allowfullscreen="allowfullscreen"></iframe>
  <div class="container">
    <div class="row">
      <div class="col">
        <div class="carousel slide" data-ride="carousel">
          <div class="carousel-inner">
            <div class="carousel-item active">
              <div class="slider-caption">
                <button class="open-video-modal" type="button" name="button" data-toggle="modal" data-target="#open-video"></button>
                <h1> <small>Lorem ipsum, dolor sit amet consectetur adipisicing elit.</small> COMBINE DESIGN</h1>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Home Video Slider end -->

<!--Video Modal start -->
<div class="modal fade" id="open-video" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">COMBINE DESIGN</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
      </div>
      <div class="modal-body">
        <div class="row">
          <div class="col">
            <iframe src="https://player.vimeo.com/video/171139017" width="100%" height="450" frameborder="0" allow="fullscreen" allowfullscreen="allowfullscreen"></iframe>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!--Video Modal end -->

<!-- Gallery section start -->


 <div class="container">
  <div class="row">
    <?php
  $wp_gallery = array(
    'post_type' => 'gallery',
    'post_status' => 'publish'
  );
  $cabo_query = new wp_query($wp_gallery);
  if($cabo_query->have_posts()){
    $cabo_query->the_post();
    $post_type = get_post_type( get_the_ID() );

    ?>
    <div class="col-lg-12"> <br>
      <h2 class="theme-title"><?php echo $post_type ?> <i> <img src="<?php echo get_template_directory_uri(); ?>/images/logo-icon.png" alt=""> </i> </h2>
    </div>
    <?php } ?>
    <div class="col-lg-12">
        <section class="gallery-section">
        
    <?php
            $wp_new = array(
              'post_type' => 'gallery',
              'post_status' => 'publish',
              'order' => 'ASC'
            );
            $cabo_query = new wp_query($wp_new);
            while($cabo_query->have_posts()){
              $cabo_query->the_post();
              $image_path = wp_get_attachment_image_src(
                get_post_thumbnail_id(),'large'
              );
          ?>
          <figure> <a class="link-overlay" href="#"></a>
        <div class="gallery-img-box"> <img src="<?php echo $image_path[0]; ?>" alt=""> </div>
        <figcaption class="gallery-caption">
          <h3><?php the_title(); ?> <small> <?php the_excerpt();  ?></small> </h3>
          <p><?php the_content(); ?></p>
          <i class="fas fa-arrow-right"></i> </figcaption>
        </figure>
          <?php } ?>
      </section>
    </div>
    
    <div class="col-lg-12 text-center"> <a class="theme-button" href="#">VIEW ALL</a> </div>
  </div>
</div> 
<!-- Gallery section end -->

<div class="container">
  <div class="row">
  <?php
    $args = array(
    'post_type' => 'post' ,
    'category_name' => 'uncategorized'
    ); 
    $q = new WP_Query($args);
    if ( $q->have_posts() ) { 
    while ( $q->have_posts() ) {
    $q->the_post();
    ?>
    <div class="col-lg-12"> <br>
      <h2 class="theme-title"><?php the_title(); ?> <i> <img src="<?php echo get_template_directory_uri(); ?>/images/logo-icon.png" alt=""> </i> </h2>
    </div>
    <div class="col-lg-12">
      <div class="theme-content-text">
        <p><?php the_content(); ?></p>
      </div>
    </div>
    <?php }} ?>
  </div>
</div> 

<!-- Newest listings section start -->


 <div class="container">
  <div class="row">
  <?php
  $wp_gallery = array(
    'post_type' => 'gallery',
    'post_status' => 'publish'
  );
  $cabo_query = new wp_query($wp_gallery);
  if($cabo_query->have_posts()){
    $cabo_query->the_post();
    $post_type = get_post_type( get_the_ID() );

?>

    <div class="col-lg-12"> <br>
      <h2 class="theme-title"><?php echo $post_type ?> <i> <img src="<?php echo get_template_directory_uri(); ?>/images/logo-icon.png" alt=""> </i> </h2>
      <?php } ?>
    </div>
    <div class="col-lg-12">
      <section class="gallery-section">
      <?php
            $wp_new = array(
              'post_type' => 'gallery',
              'post_status' => 'publish',
              'order' => 'ASC'
            );
            $cabo_query = new wp_query($wp_new);
            while($cabo_query->have_posts()){
              $cabo_query->the_post();
              $image_path = wp_get_attachment_image_src(
                get_post_thumbnail_id(),'large'
              );
          ?>
        <figure> <a class="link-overlay" href="#"></a>
          <div class="gallery-img-box">
            <div class="inner-overlay-drop">
              <ul>
                <li><?php echo get_post_meta($post->ID, 'Type', true)?></li>
                <li><?php echo get_post_meta($post->ID, 'post', true)?></li>
              </ul>
            </div>
            <img src="<?php echo $image_path[0]; ?>" alt=""> </div>
          <figcaption class="gallery-caption">
            <h3><?php the_title(); ?> <small>Calas de Cabo Roig – R167</small> </h3>
            <h4> <?php echo get_post_meta($post->ID, 'price', true)?> <small><?php echo get_post_meta($post->ID, 'size', true)?></small> </h4>
            <i class="fas fa-arrow-right"></i> </figcaption>
        </figure>
        <?php } ?>
      </section>
    </div>
  </div>
</div> 
<!-- Newest listings section end -->

<!-- Footer section start -->
<?php get_footer() ?>

</body>
</html>
