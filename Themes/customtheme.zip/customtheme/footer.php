<footer class="container-fluid">
  <div class="container">
    <div class="row">
      <div class="col-sm-6 col-lg-3">
        <div class="theme-content-text">
      <?php if ( is_active_sidebar( 'sidebar-custom' ) ) { ?>
	      <ul id="sidebar">
		    <?php dynamic_sidebar('sidebar-custom'); ?>
	      </ul>
      <?php } ?>  
        </div>
      </div>
      
      <div class="col-sm-6 col-lg-3">
        <?php if ( is_active_sidebar( 'recent_post' ) ) { ?>
	      <ul id="recent">
		    <?php dynamic_sidebar('recent_post'); ?>
	      </ul>
      <?php } ?> 
      <?php
            $wp_sale = array(
              'post_type' => 'property',
              'post_status' => 'publish',
              'post_per_page' => 3
            );
            $sale_query = new wp_query($wp_sale);
            while($sale_query->have_posts()){
              $sale_query->the_post();
              $image_path = wp_get_attachment_image_src(
                get_post_thumbnail_id(),'large'
              );
          ?>
        <article class=""> <i> <img src=" <?php echo $image_path[0] ?>" alt=""> </i>
          <div class="caption-box"> <a href="#"><?php the_title(); ?></a> 
          <!-- <span> <?php the_date(); ?></span> -->
         </div>
        </article>
        <?php } ?>
       
      </div>
      <div class="col-sm-6 col-lg-3">
      <?php if ( is_active_sidebar( 'other_page' ) ) { ?>
	      <ul id="recent">
		    <?php dynamic_sidebar('other_page'); ?>
	      </ul>
      <?php } ?> 
        <ul>
        <?php
                wp_nav_menu(array(
                  'theme_location'=>'primary-menu', 'menu_class'=> 'nav-item'
                ));
              ?>
        </ul>
      </div>
      <div class="col-sm-6 col-lg-3">
      <?php if ( is_active_sidebar( 'get_in_touch' ) ) { ?>
	      <ul id="recent">
		    <?php dynamic_sidebar('get_in_touch'); ?>
      </ul>
      <?php } ?>
      <ol class="social-links">
          <li> <a href="#"><i class="fab fa-facebook-f"></i></a> </li>
          <li> <a href="#"><i class="fab fa-twitter"></i></a> </li>
          <li> <a href="#"><i class="fab fa-linkedin-in"></i></a> </li>
          <li> <a href="#"><i class="fas fa-envelope-open-text"></i></a> </li>
        </ol>
      </div>
    </div>
  </div>
</footer>

<?php wp_footer(); ?>

