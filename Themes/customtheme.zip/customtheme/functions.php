<?php

register_nav_menus(
    array('primary-menu'=>'Top Menu')
);

add_theme_support('post-thumbnails');
add_theme_support('custom-header');

// Add theme support for selective refresh for widgets.
add_theme_support( 'customize-selective-refresh-widgets' );


function my_customTheme_styles() {
    $version=wp_get_theme()->get('Version');
    wp_enqueue_style('customTheme_main_css', get_template_directory_uri() . '/css/style.css', array(), '$version', 'all' );
    wp_enqueue_style( 'custom-css', get_template_directory_uri() .'/css/custom.css' ,  'all' );
    wp_enqueue_style('customTheme_bootstrap_css', get_template_directory_uri() . '/css/bootstrap.min.css', array(), '1.0', 'all' );
    wp_enqueue_style('customTheme_fontawesome_css', get_template_directory_uri() . '/css/fontawesome.min.css', array(), '1.0', 'all' );
    wp_enqueue_style('customTheme_owl_css', get_template_directory_uri() . '/css/owl.carousel.css', array(), '1.0', 'all' );
    wp_enqueue_style('customTheme_fonts_googleapis_css', "https://fonts.googleapis.com/css?family=Oswald:200,300,400,500,600,700&display=swap", array(), '1.0', 'all' );
    wp_enqueue_style('customTheme_fonts_Roboto_css', "https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&display=swap", array(), '1.0', 'all' );
    wp_enqueue_script('customTheme_fonts_googleapis_ajax', "https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js", array(), '1.0', 'true' );
}
add_action( 'wp_enqueue_scripts', 'my_customTheme_styles' );
function my_customTheme_scripts() {
    $version=wp_get_theme()->get('Version');
    wp_enqueue_script('customTheme_bootstrap_js', get_template_directory_uri() . '/js/bootstrap.min.js', array(), '1.0', 'true' );
    wp_enqueue_script('customTheme_js', get_template_directory_uri() . '/js/customjs.js', array(), '1.0', 'true' );
    wp_enqueue_script('customTheme_owl_js', get_template_directory_uri() . '/js/owl.carousel.min.js', array(), '1.0', 'true' );
}
add_action( 'wp_enqueue_scripts', 'my_customTheme_scripts' );


function label_post_type() {
    register_post_type( 'PROPERTIES',
        array(
            'labels' => array(
                'name' => __( 'Properties' ),
                'singular_name' => __( 'property' )
            ),
            'public' => true,
            'has_archive' => true,
            'menu_icon' => 'dashicons-admin-home',
            'supports' => array(
                'title',
                'editor',
                'excerpt',
                'custom-fields',
                'thumbnail',
                'page-attributes'
            ),
        )
    );
    register_post_type( 'LABEL',
        array(
            'labels' => array(
                'name' => __( 'Menu Labels' ),
                'singular_name' => __( 'label' )
            ),
            'public' => true,
            'has_archive' => true,
            'menu_icon' => 'dashicons-tag',
            'supports' => array(
                'title',
                'editor',
                'excerpt',
                'custom-fields',
                'thumbnail',
                'page-attributes'
            ),
        )
    );
}
add_action( 'init', 'label_post_type' );
function homes_post_type() {
    register_post_type( 'CABO',
        array(
            'labels' => array(
                'name' => __( 'Cabo Show' ),
                'singular_name' => __( 'Cabo' )
            ),
            'public' => true,
            'has_archive' => true,
            'menu_icon' => 'dashicons-admin-multisite',
            'supports' => array(
                'title',
                'editor',
                'excerpt',
                'custom-fields',
                'thumbnail',
                'page-attributes'
            ),
        )
    );
}
add_action( 'init', 'homes_post_type' );

function gallery_post_type() {
    register_post_type( 'Gallery',
        array(
            'labels' => array(
                'name' => __( 'Gallery Show' ),
                'singular_name' => __( 'Gallery' )
            ),
            'public' => true,
            'has_archive' => true,
            'menu_icon' => 'dashicons-images-alt',
            'supports' => array(
                'title',
                'editor',
                'excerpt',
                'custom-fields',
                'thumbnail'
            ),
        )
    );
}
add_action( 'init', 'gallery_post_type' );

// Theme Support
function example_theme_support() {
    remove_theme_support( 'widgets-block-editor' );
}
add_action( 'after_setup_theme', 'example_theme_support' );



//lang widget #1
function lang_widgets_init() {
    register_sidebar( array(
        'name'          => __( 'language Widget', 'textdomain' ),
        'id'            => 'lang_widget',
        'description'   => __( 'Widgets in this area will be shown on all posts and pages.', 'textdomain' ),
        'before_title'  => '<h2 class="widgettitle">',
        'after_title'   => '</h2>',
    ) );
}
add_action( 'widgets_init', 'lang_widgets_init' );

//header widget #1
function menu_widgets_init() {
    register_sidebar( array(
        'name'          => __( 'Menu Widget', 'textdomain' ),
        'id'            => 'menu_widget',
        'description'   => __( 'Widgets in this area will be shown on all posts and pages.', 'textdomain' ),
        'before_widget' => '<li  class="nav-item number">',
        'after_widget'  => '</li>',
        'before_title'  => '<h2 class="widgettitle">',
        'after_title'   => '</h2>',
    ) );
}
add_action( 'widgets_init', 'menu_widgets_init' );
//Footer #1
function wpdocs_theme_slug_widgets_init() {
    register_sidebar( array(
        'name'          => __( 'Custom Main Sidebar', 'textdomain' ),
        'id'            => 'sidebar-custom',
        'description'   => __( 'Widgets in this area will be shown on all posts and pages.', 'textdomain' ),
        'before_widget' => '<li id="%1$s" class="widget %2$s">',
        'after_widget'  => '</li>',
        'before_title'  => '<h2 class="widgettitle">',
        'after_title'   => '</h2>',
    ) );
}
add_action( 'widgets_init', 'wpdocs_theme_slug_widgets_init' );

//Footer #2

function recent_posts_widgets_init() {
    register_sidebar( array(
        'name'          => __( 'Recent Posts', 'textdomain' ),
        'id'            => 'recent_post',
        'description'   => __( 'Widgets in this area will be shown on all posts and pages.', 'textdomain' ),
        'before_widget' => '<li id="%1$s" class="widget %2$s">',
        'after_widget'  => '</li>',
        'before_title'  => '<h2 class="widgettitle">',
        'after_title'   => '</h2>',
    ) );
}
add_action( 'widgets_init', 'recent_posts_widgets_init' );

//Footer #3

function other_page_widgets_init() {
    register_sidebar( array(
        'name'          => __( 'Other Pages', 'textdomain' ),
        'id'            => 'other_page',
        'description'   => __( 'Widgets in this area will be shown on all posts and pages.', 'textdomain' ),
        'before_widget' => '<li id="%1$s" class="widget %2$s">',
        'after_widget'  => '</li>',
        'before_title'  => '<h2 class="widgettitle">',
        'after_title'   => '</h2>',
    ) );
}
add_action( 'widgets_init', 'other_page_widgets_init' );


//Footer #4

function get_in_touch_widgets_init() {
    register_sidebar( array(
        'name'          => __( 'Get in Touch', 'textdomain' ),
        'id'            => 'get_in_touch',
        'description'   => __( 'Widgets in this area will be shown on all posts and pages.', 'textdomain' ),
        'before_widget' => '<li id="%1$s" class="widget %2$s">',
        'after_widget'  => '</li>',
        'before_title'  => '<h2 class="widgettitle">',
        'after_title'   => '</h2>',
    ) );
}
add_action( 'widgets_init', 'get_in_touch_widgets_init' );


//Social Links #4

function social_link_widgets_init() {
    register_sidebar( array(
        'name'          => __( 'Social Links', 'textdomain' ),
        'id'            => 'social_link',
        'description'   => __( 'Widgets in this area will be shown on all posts and pages.', 'textdomain' ),
    ) );
}
add_action( 'widgets_init', 'social_link_widgets_init' );

//Video 

function video_widgets_init() {
    register_sidebar( array(
        'name'          => __( 'Video' ),
        'id'            => 'video',
        'description'   => __( 'Widgets in this area will be shown on all posts and pages.' ),
    ) );
}
add_action( 'widgets_init', 'video_widgets_init' );


global $post;
add_action( 'add_meta_boxes', 'add_post_meta_boxes1' );
function add_post_meta_boxes1() {
$screen = array('cabo');
add_meta_box('cabo_1',__( 'Call to Action' ),'c_metabox1',$screen);
//add_meta_box('cta_2',__( 'Venue Information' ),'c_metabox2',$screen);
//add_meta_box('cta_3',__( 'Seating Information' ),'c_metabox3',$screen);
}

function c_metabox1($post) {
    wp_nonce_field( plugin_basename( _FILE_ ), 'dynamicMeta_noncename' );
    global $post;
    $custom = get_post_meta($post->ID, 'cta_title', true);
    echo '<div class="control-group">
          <label class="control-label" for="cta_title">Title</label>
          <div class="controls">
            <input id="cta_title" name="cta_title" type="text" class="input-xlarge" value="' . esc_attr(  $custom ) . '" style="width: 400px;">
          </div>
    </div>';
    
    $custom2 = get_post_meta($post->ID, 'cta_link', true);
    echo '<div class="control-group">
          <label class="control-label" for="cta_link">Link</label>
          <div class="controls">
            <input id="cta_link" name="cta_link" type="text" class="input-xlarge" value="' . esc_attr(  $custom2 ) . '" style="width: 400px;">
          </div>
    </div>';
    /*$custom3 = get_post_meta($post->ID, 'field_show_on_mobile_homepage', true);
    echo '<div class="control-group">
          <label class="control-label" for="field_show_on_mobile_homepage">Show on mobile homepage</label>
          <div class="controls">';?>
    <input type="checkbox" name="field_show_on_mobile_homepage" <?php if($custom3 == 'on'){ ?> checked <?php }?>>
      <?php	echo '</div>
    </div>';*/
    
    }
    
    
    // add_action( 'save_post', 'cta_postdata' );
    // function cta_postdata( $post_id ) {
        
    //     // cta title
    //    $cta_title = $_POST['cta_title'];
    //    update_post_meta($post_id,'cta_title',$cta_title);
    
        
    //     // cta link
    //    $cta_link = $_POST['cta_link'];
    //    update_post_meta($post_id,'cta_link',$cta_link);
         
    //     // cta mobile homepage
    //    $field_show_on_mobile_homepage= $_POST['field_show_on_mobile_homepage'];
    //    update_post_meta($post_id,'field_show_on_mobile_homepage',$field_show_on_mobile_homepage);
    // }



?>