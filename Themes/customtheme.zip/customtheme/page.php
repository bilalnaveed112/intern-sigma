
<?php
 get_header(); 
 ?>

<br><br><br><br><br><br><br><br>
<h2 class="theme-title"><?php the_title(); ?></h2>

<div class="container-fluid cotnt">
    <div class="theme-content-text ctnt_txt"><?php the_content(); ?></div>
</div>
<br><br><br>



<?php 
get_footer(); 
?>


